import { Configuration } from "@azure/msal-browser";

export const MsalConfig: Configuration = {
    auth: {
        clientId: `${process.env.REACT_APP_AUTH_CLIENT_ID}`,
        authority: `https://${process.env.REACT_APP_AUTH_B2C_DOMAIN}/tfp/${process.env.REACT_APP_AUTH_TENANT}/${process.env.REACT_APP_AUTH_SSO_POLICY}`,
        redirectUri: `${process.env.REACT_APP_REDIRECT_URI}`,
        knownAuthorities : [`https://${process.env.REACT_APP_AUTH_B2C_DOMAIN}/tfp/${process.env.REACT_APP_AUTH_TENANT}/${process.env.REACT_APP_AUTH_SSO_POLICY}`]
    },
    cache: {
        cacheLocation: "sessionStorage",
        storeAuthStateInCookie: false, 
    }
}

export const LoginRequest = {
    scopes: [`${process.env.REACT_APP_SCOPE}`]
};