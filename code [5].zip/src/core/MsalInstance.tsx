import { PublicClientApplication } from "@azure/msal-browser";
import { MsalConfig } from "./AuthConfig";

export const MsalInstance = new PublicClientApplication(MsalConfig);