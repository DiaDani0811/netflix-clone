import axios from 'axios'

export const ApiService = {
    BaseUrl: `${process.env.REACT_APP_API_BASE_URL}`,

    get(url: string, options?: any): Promise<any> {
        return axios.get(`${this.BaseUrl}${url}`);
    },
      
    post(url: string, data?: any, options?: any): Promise<any> {
        return axios.post(`${this.BaseUrl}${url}`, data);
    },
     
    put(url: string, data?: any, options?: any): Promise<any> {
        return axios.put(`${this.BaseUrl}${url}`, data);
    },
      
    delete(url: string, options?: any): Promise<any> {
        return axios.delete(`${this.BaseUrl}${url}`);
    }
    // errorHandler(err: any): void {

    // }
}