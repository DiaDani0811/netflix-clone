var pendingRequest = 0;

const Loader = {

    newRequest: () => {
        ++pendingRequest;
        let spinnerElement = document.getElementById('app-spinner')
        if (!!spinnerElement) spinnerElement.style.display = 'block';
    },
    
    removeRequest: () => {
        --pendingRequest;
        if(pendingRequest === 0) {
            let spinnerElement = document.getElementById('app-spinner')
            if (!!spinnerElement) spinnerElement.style.display = 'none';
        }
    }
} 

Object.freeze(Loader);
export { Loader };