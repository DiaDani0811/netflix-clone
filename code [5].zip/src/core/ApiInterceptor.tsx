import axios from "axios";
import { LoginRequest } from "./AuthConfig";
import { MsalInstance } from "./MsalInstance";
import { Loader } from "./LoaderService";

export async function ApiInterceptor() {

    // let pendingRequest = 0;

    axios.interceptors.request.use((request: any) => {
        Loader.newRequest();
        return acquireAccessToken().then((token) => {
            request.headers['Ocp-Apim-Subscription-Key'] = `${process.env.REACT_APP_SUBSCRIPTION_KEY}`;
            request.headers['Authorization'] = `Bearer ${token}`;
            return Promise.resolve(request);
        }, (err) => {
            Loader.removeRequest();
            return Promise.reject(err);
        })
        // Do something before request is sent
        // return request;
    }, (error) => {
        // Do something with request error
        Loader.removeRequest();
        return Promise.reject(error);
    });

    // Add a response interceptor
    axios.interceptors.response.use((response: any) => {
        setTimeout(() => {           
            Loader.removeRequest();
        }, 200);

        // Do something with response data
        return response.data;
    }, (error) => {
        // Do something with response error
        Loader.removeRequest();
        return Promise.reject(error);
    });
}



const acquireAccessToken = async () => {
    const msalInstance = MsalInstance;
    const activeAccount = msalInstance.getActiveAccount(); // This will only return a non-null value if you have logic somewhere else that calls the setActiveAccount API
    const accounts = msalInstance.getAllAccounts();
    if (!activeAccount && accounts.length === 0) {
        /*
        * User is not signed in. Throw error or wait for user to login.
        * Do not attempt to log a user in outside of the context of MsalProvider
        */
        return;
    }
    const request = {
        ...LoginRequest,
        account: activeAccount || accounts[0]
    };

    return new Promise((resolve) => {
        msalInstance.acquireTokenSilent(request)
            .then((authResult) => { resolve(authResult.accessToken) }).catch((err) => {
                msalInstance.logoutRedirect();
            });
    });
};