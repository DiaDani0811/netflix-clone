import {
  IonContent,
  IonFooter,
  IonIcon,
  IonItem,
  IonItemDivider,
  IonLabel,
  IonList,
  IonListHeader,
  IonMenu,
  IonMenuToggle,
} from "@ionic/react";

import { useLocation } from "react-router-dom";
import {
  caretDownOutline,
  caretForwardOutline,
  homeSharp,
  logOutOutline,
  recordingSharp,
  settingsSharp,
} from "ionicons/icons";
import "./Menu.css";
import { useMsal } from "@azure/msal-react";
import { TokenClaim } from "../../models/TokenClaim";
import { useState } from "react";

const Menu: React.FC<{ name: string }> = (props) => {
  const location = useLocation();
  const { instance, accounts } = useMsal();
  const [isVisible, setIsVisible] = useState(false);
  let tokenClaim: TokenClaim = accounts[0]?.idTokenClaims as TokenClaim;

  return (
    <IonMenu contentId="main" type="overlay">
      <IonContent>
        <IonList className="py-none h-100" lines="none" id="menu-list">
          <div id="main-menu">
            <IonListHeader>{props.name}</IonListHeader>
            <IonItemDivider />
            <IonMenuToggle autoHide={false}>
              <IonItem
                routerLink="/protocols"
                className={location.pathname === "/protocols" ? "selected" : ""}
                routerDirection="none"
                lines="none"
                detail={false}
              >
                <IonIcon slot="start" icon={homeSharp} />
                <IonLabel>Home</IonLabel>
              </IonItem>
            </IonMenuToggle>
            
            <IonItem
              routerLink="/admin/submittedrecords"
              className={location.pathname === "/admin/submittedrecords" ? "selected" : ""}
              button
              onClick={() => {
              }}
              routerDirection="none"
              lines="none"
              detail={false}
            >
              <IonIcon slot="start" icon={recordingSharp} />
              <IonLabel>Report</IonLabel>
            </IonItem>

            <IonItem
              button
              onClick={() => {
                setIsVisible(true);
                if (isVisible === true) {
                  setIsVisible(false);
                }
              }}
              routerDirection="none"
              lines="none"
              detail={false}
            >
              <IonIcon slot="start" icon={settingsSharp} />
              <IonLabel>Settings</IonLabel>
              <IonIcon
                slot="end"
                icon={isVisible ? caretDownOutline : caretForwardOutline}
              ></IonIcon>
            </IonItem>
            <IonMenuToggle autoHide={isVisible ? false : true}>
              <IonList
                className="ion-no-padding"
                style={{ marginLeft: "13px" }}
                id="sub-menu-list"
              >
                {
                  //SE-CHANGES = User
                  tokenClaim?.roles.some(x => x === 'soa.CustomerAdmin' || x === 'soa.SuperAdmin' || x === 'soa.User')  && (
                  <IonItem
                    routerLink="/admin/settings"
                    className={
                      location.pathname === "/admin/settings" ? "selected" : ""
                    }
                    routerDirection="none"
                    lines="none"
                    detail={false}
                  >
                    <img
                      className="sub-menu-icon"
                      src="assets/icon/admin.png"
                    />
                    <IonLabel>Admin</IonLabel>
                  </IonItem>
                 )
                }
                {/* <IonItem routerDirection="none" lines="none" detail={false}>
                  <img
                    className="sub-menu-icon"
                    src="assets/icon/account.png"
                  />
                  <IonLabel>Account</IonLabel>
                </IonItem>
                <IonItem routerDirection="none" lines="none" detail={false}>
                  <img
                    className="sub-menu-icon"
                    src="assets/icon/notification.png"
                  />
                  <IonLabel>Notifications</IonLabel>
                </IonItem>
                <IonItem routerDirection="none" lines="none" detail={false}>
                  <img
                    className="sub-menu-icon"
                    src="assets/icon/appearance.png"
                  />
                  <IonLabel>Appearance</IonLabel>
                </IonItem> */}
                <IonItem routerDirection="none" lines="none" detail={false}>
                  <img
                    className="sub-menu-icon"
                    src="assets/icon/helpandsupport.png"
                  />
                  <IonLabel>Help and Support</IonLabel>
                </IonItem>
              </IonList>
            </IonMenuToggle>
          </div>
        </IonList>
      </IonContent>
      <IonFooter>
        <IonList id="footer-menu">
          <IonMenuToggle autoHide={false}>
            <IonItem
              routerLink="/about"
              routerDirection="none"
              lines="none"
              detail={false}
            >
              <IonIcon slot="start" />
              <IonLabel>About</IonLabel>
            </IonItem>
            <IonItem
              routerLink="/"
              routerDirection="none"
              lines="none"
              detail={false}
            >
              <IonIcon slot="start" />
              <IonLabel>Terms of use</IonLabel>
            </IonItem>
            <IonItem
              lines="none"
              button
              detail={false}
              onClick={() => instance.logout()}
            >
              <IonIcon slot="start" icon={logOutOutline} />
              <IonLabel>Logout</IonLabel>
            </IonItem>
          </IonMenuToggle>
        </IonList>
      </IonFooter>
    </IonMenu>
  );
};

export default Menu;
