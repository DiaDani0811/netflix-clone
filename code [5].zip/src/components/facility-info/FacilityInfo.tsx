import { IonCol, IonGrid, IonItem, IonRow, IonSelect, IonSelectOption, useIonRouter } from "@ionic/react";
import { useContext, useState } from "react";
import { useLocation } from "react-router";
import { Facility } from "../../models/Facility";
import { SharedStoreContext } from "../../shared/SharedStore";

import './FacilityInfo.css';

const FacilityInfo: React.FC = () => {
    const location = useLocation();
    const { user, allFacilities, selectedFacility, updateFacilityInfo } = useContext(SharedStoreContext);

    const [selectedFac, setSelectedFac] = useState<Facility>(selectedFacility);

    const router = useIonRouter();

    return <IonGrid>
        <IonRow>
            <IonCol offset="2" size="8" offsetSm="0" sizeSm="6" sizeXl="4"> 
                <IonItem disabled={location.pathname !== "/protocols"}>
                    <img className="v-align-middle icon-img" src="assets/icon/facility_icon.png" />
                    <IonSelect interface="popover" value={selectedFac} compareWith={(o1, o2) => {
                        return o1 && o2 ? o1.id === o2.id : o1 === o2;
                    }} className="v-align-middle" onIonChange={(e) => {
                        if (selectedFac.id !== e.detail.value?.id) {
                            setSelectedFac(e.detail.value);
                            if(e.detail.value.id){
                                updateFacilityInfo(e.detail.value.id);
                                router.push('/protocols', 'root', 'replace');
                            }
                        }
                    }}>
                        {
                            allFacilities.map(fac => {
                                return <IonSelectOption key={fac.id} value={fac}>{fac.facilityName}</IonSelectOption>
                            })
                        }
                    </IonSelect>
                </IonItem>
            </IonCol>
        </IonRow>
    </IonGrid>
}

export default FacilityInfo;