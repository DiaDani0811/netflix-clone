import React, { useState } from 'react';
import { chevronBackOutline } from 'ionicons/icons'
import { IonButtons, IonButton, IonHeader, IonMenuButton, IonAlert, IonTitle, IonToolbar, IonIcon } from '@ionic/react';
import './Header.css';
import { useAccount, useMsal } from '@azure/msal-react';

type Props = {
  formState?: boolean;
};

const Header: React.FC<Props> = ({formState}) => {
  const [backButtonAlert, setBackButtonAlert] = useState<any>(false) ;
  const { accounts,} = useMsal();
  const account = useAccount(accounts[0] || {});

  const backButtonHandler = () =>{
    setBackButtonAlert(true)
  }
  
  const moveBackHandler = () =>{
    window.history.back()
    setBackButtonAlert(false)
  }
  

  return (
      <IonHeader mode="md">
        <IonToolbar className="ion-text-center">    
        {account && <IonButton  fill="clear" className="button-slot" slot="start" onClick={formState? backButtonHandler : moveBackHandler }>
              <IonIcon icon={chevronBackOutline} style={{color: "#000000"}} ></IonIcon>
            </IonButton>}
            <IonAlert
            isOpen={backButtonAlert}
            subHeader="Are you sure you want to leave this page?"
            header="You have unsaved changes!"
            buttons={[
              {
                text: 'Cancel',
                role: 'cancel',
                handler: () => {
                  
                },
              },
              {
                text: 'OK',
                role: 'confirm',
                handler: () => {
                  window.history.back()
                },
              },
            ]}
            onDidDismiss={() => setBackButtonAlert(false)}
          ></IonAlert>

          <IonTitle>
              <img className="syk-logo ion-hide-sm-down ion-float-sm-left" src="assets/icon/soa_logo.png" />
              <img className="syk-logo ion-float-sm-right" src="assets/stryker_logo2015.png" />
          </IonTitle>
          <IonButtons className="button-slot" slot="end">
            <IonMenuButton style={{color: "#000000"}}/>
          </IonButtons>
        </IonToolbar>
      </IonHeader>
  );
};

export default Header;
