import { IonRow, IonCol } from "@ionic/react"
import React, { useContext, useEffect, useState } from "react"
import { ApiService } from "../../core/ApiService"
import { AssessmentType } from "../../models/AssessmentType"
import { Questionnaire } from "../../models/Questionnaire"
import { QuestionnaireDto, QuestionnaireDtoMapper } from "../../models/QuestionnaireDto"
import { RequiredAssessment } from "../../models/RequiredAssessment"
import { RequiredAssessmentDto } from "../../models/RequiredAssessmentDto"
import { SharedStoreContext } from "../../shared/SharedStore"
import DynamicForm from "../dynamic-form/DynamicForm"
import AssessmentSubmittedCard from "./AssessmentSubmittedCard"

type FormState ={
  onFormStateChange: (formState: boolean) => void;
}

const RequiredAssessmentTemplate: React.FC<{ initiative: RequiredAssessment, formStateChange: any }> = ({ initiative , formStateChange}) => {

  const [questionnaire, setQuestionnaire] = useState<Questionnaire>({ name: '', sections: [] });
  const [assesmentSubmitted, setAssesmentSubmitted] = useState<boolean>(false);
  const { selectedFacility, user, updateFacilityInfo } = useContext(SharedStoreContext);

  useEffect(() => {
    !!initiative && setQuestionnaire(JSON.parse(initiative?.questionnaire));
  }, [initiative]);

  const handleFormStateChange = (formState: boolean) =>{
    formStateChange(formState)
  }

  const handleSubmit = (data: any) => {
    if (!!data && !!initiative && !!questionnaire) {
      const QuestionDto: QuestionnaireDto[] = QuestionnaireDtoMapper(data, questionnaire);
      const AssessmentDto: RequiredAssessmentDto = {
        RequiredAssessmentTemplateId: initiative.id,
        UserEmail: user.email,
        FacilityId: selectedFacility.id,
        AssessmentData: {
          Data: JSON.stringify(QuestionDto)
        }
      }
      return new Promise((resolve, reject) => {
        ApiService.post(`/api/assessment/${AssessmentType.Required}`, AssessmentDto).then((resp: any) => {
          resolve(resp);
          setTimeout(() => {
            setAssesmentSubmitted(true);
            updateFacilityInfo(selectedFacility.id); //To get the updated facility details.
          }, 100)
        }, (err: any) => reject(err));
      });
    }
    return Promise.reject('An error occurred');
  }

  return <React.Fragment>
    <IonRow><IonCol>
      <h1 className='mb-half'>{questionnaire?.name}</h1>
    </IonCol></IonRow>
    <IonRow style={{ 'flexGrow': 1 }}>
      <IonCol className='ion-no-padding pb-half'>
        {!assesmentSubmitted ?
          <DynamicForm config={questionnaire?.sections || []} onSubmit={handleSubmit} onFormStateChange={handleFormStateChange}></DynamicForm> :
          <AssessmentSubmittedCard updateFacInfo={() => updateFacilityInfo(selectedFacility.id)}></AssessmentSubmittedCard>
        }
      </IonCol>
    </IonRow>
  </React.Fragment>
}

export default RequiredAssessmentTemplate;