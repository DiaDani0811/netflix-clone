import { IonButton, IonCard, IonCardContent, IonCol, IonGrid, IonIcon, IonRow, IonText } from "@ionic/react";
import { checkmarkCircleOutline } from "ionicons/icons";

import './AssessmentSubmittedCard.css';

const AssessmentSubmittedCard: React.FC<{updateFacInfo: () => void }> = ({updateFacInfo}) => {

    return (
        <IonCard className='ion-no-margin h-100'>
            <IonCardContent className='h-100'>
                <IonGrid className='flex-grid'>
                    <IonRow>
                        <IonCol className='ion-no-padding ion-text-center'>
                            <IonIcon icon={checkmarkCircleOutline} className='completed-icon' />
                        </IonCol>
                    </IonRow>
                    <IonRow className="ion-margin-top ion-padding-top">
                        <IonCol className='ion-no-padding ion-text-center'>
                            <IonText className='completed-text'>Submission successfully completed</IonText>
                        </IonCol>
                    </IonRow>
                    <IonRow style={{'marginTop': 'auto'}}>
                        <IonCol className='ion-no-padding ion-text-center'>
                            <IonButton expand="block" size="large" routerLink="/protocols" onClick={updateFacInfo}
                                routerDirection="root">Go to dashboard</IonButton>
                        </IonCol>
                    </IonRow>
                </IonGrid>
            </IonCardContent>
        </IonCard>
    )

}

export default AssessmentSubmittedCard;