import {
  IonButton,
  IonDatetime,
  IonIcon,
  IonInput,
  IonItem,
  IonLabel,
  IonPopover,
} from "@ionic/react";
import { useField } from "formik";
import { calendar } from "ionicons/icons";
import { format, parseISO } from "date-fns";
import { useState } from "react";

export const DatePicker: React.FC<any> = ({ label, isRequired, ...props }) => {
  const [field, meta, helper] = useField<string>(props);
  const [validationError, setValidationError] = useState<any>("");
  const displayFormat = 'MM/dd/yyyy';
  const validateDateFormat = (inputDate: any) => {
    if (inputDate) {
      const [month, day, year] = inputDate.split("/");
      const isoFormattedStr = `${year}-${month}-${day}`;
      const utcTimestamp = Date.UTC(year, month - 1, day);
      if (!Number.isNaN(utcTimestamp)) {
        const toISOString = new Date(utcTimestamp);
        if (toISOString.getUTCFullYear() === Number(year) &&
          toISOString.getUTCMonth() === Number(month) - 1 &&
          toISOString.getUTCDate() === Number(day)) {
          helper.setValue(isoFormattedStr, true);
          setValidationError("");
          return true;
        } else {
          helper.setValue("", true);
          setValidationError("Invalid Format");
          return false;
        }
      } else {
        helper.setValue("", true);
        setValidationError("Invalid Format");
        return false;
      }
    } else {
      helper.setValue("", true);
      setValidationError("");
    }
  };
  return (
    <div className='ion-padding-top'>
      <IonLabel position="floating">{label}{label && isRequired && <span className="mandatory-field">*</span>}</IonLabel>
      <IonItem key={field.name} mode="md" fill="outline">
        <IonInput id={`${field.name}-date-input`} name={field.name} placeholder={'MM/DD/YYYY'}
          value={field.value ? format(parseISO(field.value), displayFormat) : ""}
          onBlur={(e) => {
            helper.setTouched(true);
            validateDateFormat(e.target.value);
          }} />
        <IonButton fill="clear" id={`${field.name}-open-date-input`}>
          <IonIcon icon={calendar} />
        </IonButton>
        <IonPopover side="left" trigger={`${field.name}-open-date-input`} showBackdrop={false}>
          <IonDatetime presentation="date" name={field.name} value={field.value} onIonChange={(e) => {
            helper.setTouched(true);
            helper.setValue(e.detail.value as string || "");
          }} />
        </IonPopover>
      </IonItem>
      {!!props.hint && <div><IonLabel className='form-control-hint'>{props.hint}{!label && isRequired && <span className="mandatory-field">*</span>}</IonLabel></div>}
      {!validationError && meta.touched && !!meta.error && (
        <IonLabel color="danger">{meta.error}</IonLabel>
      )}
      {validationError && <IonLabel color="danger">{validationError}</IonLabel>}
    </div>
  );
};
