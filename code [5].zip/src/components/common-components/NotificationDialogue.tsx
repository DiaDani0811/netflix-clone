/* Using with IonAlert Component */

import React, { useEffect, useState } from "react";
import { IonAlert, IonButton, IonContent } from "@ionic/react";
import { useHistory } from "react-router-dom";

export const NotificationDialogue: React.FC<any> = ({
  message,
  openModal
}) => {
  const history = useHistory();
  const [showAlert, setShowAlert] = useState(false);

  useEffect(() => {
    setShowAlert(openModal);
  }, [openModal]);

  return (
    <IonContent>
      <IonAlert
        isOpen={showAlert}
        cssClass="my-custom-class"
        header={"Confirm!"}
        message={message}
        buttons={[
          {
            text: "Cancel",
            role: "cancel",
            cssClass: "secondary",
            id: "cancel-button",
            handler: () => {
              setShowAlert(false);
            },
          },
          {
            text: "Proceed",
            id: "confirm-button",
            handler: () => {
              history.goBack();
            },
          },
        ]}
      />
    </IonContent>
  );
};

export default NotificationDialogue;
