import { IonItem, IonLabel, IonSelect, IonSelectOption, IonItemOption } from "@ionic/react";
import { useField, Field } from "formik";

export const MultiSelectDropdown: React.FC<any> = ({ options, value, label, isRequired, ...props }) => {

    const [field, meta, helpers] = useField<string>(props);

    const onCheckboxChange = (e: CustomEvent<any>) => {
        helpers.setValue(e.detail.value, true);
    }

    const selectcomp = () =>{
        return(
         
            <IonSelect
            multiple
            interface="popover" 
            value={field.value}
            onIonChange={e => onCheckboxChange(e)}
          >
            {options.map((option: any) => (              
              <IonSelectOption key={option.id} >
                {option.value}
              </IonSelectOption>
            ))}
          </IonSelect>
        )
    }

    return (options && options.length > 0 &&
        <div className='ion-padding-top'>
            
                <IonLabel>{label}{label && isRequired && <span className="mandatory-field">*</span>}</IonLabel>
                {!!props.hint && <div><IonLabel className='form-control-hint'>({props.hint}){!label && isRequired && <span className="mandatory-field">*</span>}</IonLabel></div>}
                <IonItem key={field.name} mode="md" fill="outline">
                    <Field name={field.name} 
                      component={selectcomp} 
                      onIonChange={field.onChange}
                      placeholder={props.placeholder}/>
                    
                </IonItem>

                {meta.touched && !!meta.error && <IonLabel color='danger'>{meta.error}</IonLabel>}
        </div>
    )
};