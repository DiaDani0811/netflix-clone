import {
  IonButton,
  IonCol,
  IonIcon,
  IonLabel,
  IonRow,
  IonSelect,
  IonSelectOption,
} from "@ionic/react";
import React, { useEffect, useImperativeHandle, useState } from "react";
import "./Pagination.css";
import { chevronBackOutline,chevronDownCircleOutline, chevronForwardOutline } from "ionicons/icons";

const Pagination: React.FC<any> = ({ refs, ...props }) => {

  const [totalItems, setTotalItems] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageDataSizeValue, setPageDataSizeValue] = useState(5);
  const pageDataSetSize = [{ size: 5, value: "5" }, { size: 10, value: "10" }, { size: 20, value: "20" }];

  const totalPages = Math.ceil(totalItems / pageDataSizeValue);
  const pageNumbers = [];
  for (let i = 1; i <= totalPages; i++) {
    pageNumbers.push(i);
  }
  /*** Assign dataset from the parent component of the dataset */
  useImperativeHandle(refs, () => ({
    initPagenator(dataSet: any) {
      setTotalItems(dataSet.length);
    },

  }));

  const startIndex = (currentPage - 1) * pageDataSizeValue;
  const endIndex = startIndex + pageDataSizeValue;

  /*** Define Pagenation record size ****/
  const changePaginationSize = (e: any) => {
    setCurrentPage(1);
    setPageDataSizeValue(e.target.value);
    props.changeDataSet(0, e.target.value);
  };


  /*** Pagenation Next/Previous action ****/
  const handlePagination = (direction: "prev" | "next") => {

    var currentPageTemp = 0;
    if (direction === "prev" && currentPage > 1) {
      setCurrentPage((prevPage) => prevPage - 1);

      currentPageTemp = (currentPage - 1);
    } else if (direction === "next" && currentPage < totalPages) {
      setCurrentPage((prevPage) => prevPage + 1);

      currentPageTemp = (currentPage + 1);
    }

    /*** Records have reflect in parent component by start index and end index****/
    props.changeDataSet((currentPageTemp - 1) * pageDataSizeValue, (((currentPageTemp - 1) * pageDataSizeValue) + pageDataSizeValue));

  };

  return (
    <div className="container">
      <IonRow>
        <IonCol size-xl="3" className="ion-text-start ion-text-nowrap">
            <IonLabel className="labelTxt">Items per page:</IonLabel>
            <IonSelect
            value={pageDataSizeValue}
            className="selectBox"
            interface="popover"
            placeholder="Select User"
            onIonChange={changePaginationSize}
          >
            {pageDataSetSize.map((n: any, i) => {
              return (
                <IonSelectOption key={n.size} value={n.size} >
                  {n.size}
                </IonSelectOption>
              );
            })}
          </IonSelect>

             
        </IonCol>
    
        <IonCol size-xl="9" className="ion-text-end">
        <IonLabel className="ion-margin-end labelText">
            {startIndex + 1} - {endIndex >= totalItems ? totalItems : endIndex}  of  {totalItems}
          </IonLabel>
          <IonButton
            onClick={(e) => {
              handlePagination("prev");
            }}
            disabled={currentPage === 1}
          >
           <IonIcon icon={chevronBackOutline} style={{color: "#fff"}} ></IonIcon>
          </IonButton>
          <IonButton
            className="nextButton"
            onClick={(e) => {

              handlePagination("next");
            }}
            disabled={currentPage === totalPages}
          >
          <IonIcon icon={chevronForwardOutline} style={{color: "#fff"}} ></IonIcon>
          </IonButton>
        </IonCol>
      </IonRow>
    </div>
  );
};
export default Pagination;
