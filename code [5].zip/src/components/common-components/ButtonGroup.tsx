import { useEffect, useState } from "react";
import "./ButtonGroup.css";

const ButtonGroup = ({ buttons, afterButtonGroupClicked }: any) => {
  const [clickedButton, setClickedButton] = useState<any>();
  const [checkedButtons, setCheckedButtons] = useState(buttons);

  const handleClick = (name: string) => {
    const clickedButton = buttons.filter((x: any) => x.name === name);
    clickedButton[0].selected =
      clickedButton && clickedButton.length > 0 && clickedButton[0].selected
        ? false
        : true;

    setClickedButton(clickedButton);
    setCheckedButtons(buttons);
    afterButtonGroupClicked(buttons, clickedButton[0]);
  };

  useEffect(() => {
    if (clickedButton) {
      let clickedItem = checkedButtons.filter(
        (x: any) => x.name === clickedButton[0].name
      );
      clickedItem = clickedButton;
      setCheckedButtons(checkedButtons);
    }
  }, [buttons]);

  return (
    <>
      {checkedButtons.map((button: any, i: number) => (
        <button
          key={i}
          name={button.name}
          onClick={() => handleClick(button.name)}
          className={button.selected ? "customButton active" : "customButton"}
        >
          {button.name}
        </button>
      ))}
    </>
  );
};

export default ButtonGroup;
