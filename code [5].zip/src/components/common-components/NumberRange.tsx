import { IonItem, IonLabel, IonRange, IonText } from "@ionic/react";
import { Field, useField } from "formik";

export const NumberRange: React.FC<any> = ({ label, range, isRequired, ...props }) => {
    const [field, meta] = useField<string>(props);
    return (
        <div className='ion-padding-top'>
            <IonLabel>{label}{label && isRequired && <span className="mandatory-field">*</span>}</IonLabel>
            {!!props.hint && <div><IonLabel className='form-control-hint'>({props.hint}){!label && isRequired && <span className="mandatory-field">*</span>}</IonLabel></div>}
            <IonItem lines="none" key={field.name}>
                <Field
                    className='px-none'
                    name={field.name}
                    onIonChange={field.onChange}
                    as={IonRange}
                    min={range[0]}
                    max={range[1]}
                    snaps={true}
                    value={field.value}
                    pin={true}
                >
                    <IonLabel slot="start">{range[0]}</IonLabel>
                    <IonLabel slot="end">{range[1]}</IonLabel>
                </Field>
            </IonItem>
            {!!meta.error && <IonLabel color='danger'>{meta.error}</IonLabel>}
        </div>
    )
};