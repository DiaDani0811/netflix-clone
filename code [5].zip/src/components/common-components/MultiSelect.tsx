import { IonList, IonListHeader, IonItem, IonLabel, IonCheckbox, IonSelect } from "@ionic/react";
import { useField } from "formik";
import { CheckboxChangeEventDetail } from '@ionic/core';

export const MultiSelect: React.FC<any> = ({ options, label, isRequired, ...props }) => {
    const [field, meta, helpers] = useField<string>(props);
    const onCheckboxChange = (e: CustomEvent<CheckboxChangeEventDetail<any>>) => {

        let fieldValue: string;
        if (e.detail.checked) {
            (field.value && field.value.includes(e.detail.value) ? fieldValue = field.value : (field.value?.trim().length > 0 ? fieldValue = field.value + ',' + e.detail.value : fieldValue = e.detail.value));
        } else {
            (field.value && field.value.includes(e.detail.value) ? fieldValue = field.value.replace(e.detail.value, '') : fieldValue = field.value);
        }



        // ----------------For Disabled------------------>

// if(disabled && e.detail.checked ){    
//     disabled.forEach((isDisabled:DisabledOn) => {
//         if(isDisabled.valueId === e.detail.value) {
//             setDisabledOn(true)     
//             fieldValue = "";
//             fieldValue = e.detail.value;
//         }
//     });
// }else{
//     setDisabledOn(false)
// }

        // in case multiple values were unchecked
        // in case the last selected value is followed by comma
        fieldValue = !!fieldValue ? fieldValue.replace(',,', ',').replace(/,\s*$/, "") : '';
        helpers.setValue(fieldValue, true);
    }
    return (options && options.length > 0 &&
        <div className='ion-padding-top'>
            <IonList key={field.name} lines='none' {...field}>
                <IonLabel>{label}{label && isRequired && <span className="mandatory-field">*</span>}</IonLabel>
                {!!props.hint && <div><IonLabel className='form-control-hint'>({props.hint}){!label && isRequired && <span className="mandatory-field">*</span>}</IonLabel></div>}
                {options.map((option: any) => {
                    return (
                        <IonItem key={option.id}>
                            
                            <IonLabel>{option.value}</IonLabel>
                            <IonCheckbox slot='start' mode="md" id={option.id} name={field.name} checked={field.value?.includes(option.id) || false} value={option.id}
                                onIonChange={e => onCheckboxChange(e)}></IonCheckbox>
                        </IonItem>
                    )
                })}
            </IonList>
            {meta.touched && !!meta.error && <IonLabel color='danger'>{meta.error}</IonLabel>}
        </div>
    )
};