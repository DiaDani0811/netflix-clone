import { IonItem, IonLabel, IonInput } from "@ionic/react";
import { Field, useField, useFormikContext } from "formik";
import { useEffect, useState } from "react";

export const Input: React.FC<any> = ({ label, isRequired, ...props }) => {
  const [field, meta, helper] = useField<string | number>(props);
  const [disabled, setDisabled] = useState(false);
  const { values, touched } = useFormikContext<any>();

  const setField = (value: number) => {
    if(value) {
        helper.setValue(value, true);
        setDisabled(true);
    } else {
        setDisabled(false);
    }
  }
  useEffect(() => {
    if (props.dependsOn) {
      if (Array.isArray(props.dependsOn)) {
        let value = 0;
        (props.dependsOn as Array<any>).forEach((dependsOnCond: any) => {
          if (!isNaN(parseInt(values[dependsOnCond]))) {
            value += values[dependsOnCond];
          }
        });
        setField(value);
      } else {
        if (values[props.dependsOn] && touched[props.dependsOn]) {
          if (props.helperData && props.identifier) {
              let value = props.helperData[props.identifier][values[props.dependsOn]];
              setField(value);
          }
        } else {
          setDisabled(false);
        }
      }
    }
  }, [JSON.stringify(values), JSON.stringify(touched)]);
  return (
    <div className="ion-padding-top">
      <div className={props.inline ? "inline-field" : ""}>
        <IonLabel position="floating">
          {label}
          {label && isRequired && <span className="mandatory-field">*</span>}
        </IonLabel>
        <IonItem key={field.name} mode="md" fill="outline">
          <Field
            disabled={props.disabled}
            name={field.name}
            type={props.type}
            // value={props.value}
            onIonChange={field.onChange}
            placeholder={props.placeholder}
            as={IonInput}
            min={props.min}
            max={props.max}
          ></Field>
        </IonItem>
      </div>
      {!!props.hint && (
        <div>
          <IonLabel className="form-control-hint">
            {props.hint}
            {!label && isRequired && <span className="mandatory-field">*</span>}
          </IonLabel>
        </div>
      )}
      {meta.touched && !!meta.error && (
        <IonLabel color="danger">{meta.error}</IonLabel>
      )}
    </div>
  );
};
