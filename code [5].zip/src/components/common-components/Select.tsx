import { IonItem, IonLabel, IonSelectOption, IonSelect } from "@ionic/react";
import { Field, useField, useFormikContext } from "formik";
import { useEffect, useState } from "react";

export const Select: React.FC<any> = ({ label, options, isRequired, ...props }) => {
    const [field, meta, helper] = useField<string>(props);
    const [disabled, setDisabled] = useState(false);

    const { values, touched } = useFormikContext<any>();
    useEffect(() => {
        if (props.dependsOn) {
            if (values[props.dependsOn] && touched[props.dependsOn]) {
                if (props.helperData && props.identifier) {
                    let option = options.find((x: any) => x.value === props.helperData[props.identifier][values[props.dependsOn]]);
                    if (option) {
                        helper.setValue(option.id);
                        setDisabled(true);
                    } else {
                        setDisabled(false);
                    }
                }
            } else {
                setDisabled(false);
            }
        }
    }, [values[props.dependsOn], touched[props.dependsOn]])

    return ((options && options.length > 0) ?
        <div className='ion-padding-top'>
            <IonLabel>{label}{label && isRequired && <span className="mandatory-field">*</span>}</IonLabel>
            <IonItem mode="md" fill="outline">
                <Field as={IonSelect} name={field.name} interface="popover" disabled={disabled} placeholder={props.placeholder} onIonChange={field.onChange}>
                    {options?.map((option: any) => {
                        return <IonSelectOption key={option.id} value={option.id}>{option.value}</IonSelectOption>
                    })}
                </Field>
            </IonItem>
            {!!props.hint && <div><IonLabel className='form-control-hint'>{props.hint}{!label && isRequired && <span className="mandatory-field">*</span>}</IonLabel></div>}
            {meta.touched && !!meta.error && <IonLabel color='danger'>{meta.error}</IonLabel>}
        </div> : <></>
    )
};