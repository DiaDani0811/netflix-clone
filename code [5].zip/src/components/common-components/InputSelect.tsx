import { IonLabel } from "@ionic/react";
import { Field, useField } from "formik";
import { useState } from "react";
import Creatable from "react-select/creatable";
import "../dynamic-form/DynamicForm.css";

const InputSelect: React.FC<any> = ({
  options,
  label,
  isRequired,
  ...props
}) => {
  const [field, meta, helper] = useField<string>(props);
  const defaultOptions = [] as any;
  const [newValue, setValue] = useState<any>(field.value);

  options.forEach((option: any) => {
    const value = { value: option.id, label: option.value };
    defaultOptions.push(value);
  });
  const handleInputChange = (inputValue: any, action: any) => {
    if (action.action !== "input-blur" && action.action !== "menu-close") {
      helper.setTouched(true);
      helper.setValue(inputValue, true);
      setValue(inputValue);
    }
  };
  return (
    <div className="ion-padding-top">
      <IonLabel position="floating">
        {label}
        {label && isRequired && <span className="mandatory-field">*</span>}
      </IonLabel>
      <Field
        className="input-select-container"
        classNamePrefix="input-select"
        name={field.name}
        as={Creatable}
        options={defaultOptions}
        placeholder={''}
        inputValue={newValue}
        value={
          defaultOptions
            ? defaultOptions.find((option: any) => option.value === field.value)
            : ""
        }
        onChange={(option: { value: string; label: string }) => {
          helper.setTouched(true);
          helper.setValue(option ? option.label : field.value);
        }}
        formatCreateLabel={() => undefined}
        onInputChange={handleInputChange.bind(this)}
      ></Field>
      {!!props.hint && (
        <div>
          <IonLabel className="form-control-hint">
            {props.hint}
            {!label && isRequired && <span className="mandatory-field">*</span>}
          </IonLabel>
        </div>
      )}
      {meta.touched && !!meta.error && (
        <IonLabel color="danger">{meta.error}</IonLabel>
      )}
    </div>
  );
};

export default InputSelect;
