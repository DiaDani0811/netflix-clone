import { IonLabel } from "@ionic/react";

export const Label: React.FC<any> = ({ label, isRequired, ...props }) => {

    return (
        <div className='ion-padding-top'>
            <IonLabel position="floating">{label}{label && isRequired && <span className="mandatory-field">*</span>}</IonLabel>
            {!!props.hint && <div><IonLabel className='form-control-hint'>{props.hint}{!label && isRequired && <span className="mandatory-field">*</span>}</IonLabel></div>}
        </div>
    )
};