import { IonItem, IonLabel, IonInput, IonRadio, IonRadioGroup } from "@ionic/react";
import { Field, useField } from "formik";

export const Radio: React.FC<any> = ({ label, options, isRequired, ...props }) => {
  const [field, meta] = useField<string>(props);
  return (
    <div className='ion-padding-top'>
      <Field as={IonRadioGroup} key={field.name} name={field.name} onIonChange={field.onChange}>
        <IonLabel>{label}{label && isRequired && <span className="mandatory-field">*</span>}</IonLabel>
        {!!props.hint && <div><IonLabel className='form-control-hint'>({props.hint}){!label && isRequired && <span className="mandatory-field">*</span>}</IonLabel></div>}
        {options.map((option: any) => {
          return (
            <IonItem lines="none" key={option.id}>
              <IonLabel>{option.value}</IonLabel>
              <Field type="radio" name={field.name} mode="md" as={IonRadio} slot='start' value={option.id}></Field>
            </IonItem>
          )
        })}
      </Field>
      {meta.touched && !!meta.error && <IonLabel color='danger'>{meta.error}</IonLabel>}
    </div>
  )
};