import { IonCard, IonCardHeader, IonCardSubtitle, IonCardTitle, IonRow } from '@ionic/react';
import './Tile.css';

const Tile: React.FC<{title?: string, subtitle?:string, imgurl?: string; navigationUri: string, disabled?: boolean}> = ({title, subtitle, imgurl, navigationUri, disabled}) => {

  return (
    <IonCard className="ion-padding-vertical ion-no-margin card-tile" disabled={disabled} routerLink={navigationUri}>
      <IonRow className="ion-padding-top ion-padding-start">
        <img className="icon-img" src={`assets/icon/${imgurl}`} />
      </IonRow>
      <IonRow className="">
        <IonCardHeader>
          <IonCardTitle>{title}</IonCardTitle>
          <IonCardSubtitle>{subtitle}</IonCardSubtitle>
        </IonCardHeader>
     </IonRow>
    </IonCard>
  );
};

export default Tile;
