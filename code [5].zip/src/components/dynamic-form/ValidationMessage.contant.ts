import format from "date-fns/format";

export const ValidationMsg:any = {
    required : 'This field is required.',
    email: 'Enter a valid email address.',
    max: 'The maximum allowed value is ${max}.',
    min: 'The minimum allowed value is ${min}.',
    mindate: (val:any) => `The minimum allowed value is ${val.min ? format(val.min, 'MM/dd/yyyy') : ''} `,
    maxlength: 'The maximum length is ${max}.',
    minlength: 'The minimum length is ${min}.',
    number: 'Only numeric values are allowed.',
    pattern: 'The format should be {value}.'
};
