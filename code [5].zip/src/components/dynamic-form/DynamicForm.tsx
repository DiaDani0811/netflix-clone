import React, { useEffect, useState } from 'react';
import { Form, Formik, FormikProps } from 'formik';
import { IonButton, IonCard, IonCardContent, IonCardHeader, IonCardSubtitle, IonCardTitle, IonCol, IonGrid, IonIcon, IonItem, IonLabel, IonRow, IonText } from '@ionic/react';
import * as Yup from 'yup';

import './DynamicForm.css'
import { MultiSelect } from '../common-components/MultiSelect';
import { Input } from '../common-components/Input';
import { Radio } from '../common-components/Radio';
import { Select } from '../common-components/Select';
import { NumberRange } from '../common-components/NumberRange';
import { DatePicker } from '../common-components/DatePicker';
import { ValidationMsg } from './ValidationMessage.contant';
import { checkmark } from 'ionicons/icons';
import { DependsOn, Question, QuestionnaireSection } from '../../models/Questionnaire';
import { format, parseISO } from "date-fns";
import InputSelect from '../common-components/InputSelect';
import { Label } from '../common-components/Label';

type FormStateProp = {
  onFormStateChange: (formState: boolean) => void;
};

const DynamicForm: React.FC<{ config: Array<QuestionnaireSection>, onSubmit: (data: any) => Promise<any>, helperData?: any, round?: number, formData?: any, onFormStateChange:any}> = ({ config, onSubmit, helperData = {}, round = 0, formData = {}, onFormStateChange} ) => {

  const [activeStep, setActiveStep] = useState(0);
  const [validationSchema, setValidationSchema] = useState<any>(Yup.object().shape({}));
  const [hasReviewed, setHasReviewed] = useState(false);

  const [isFormDirty, setFormDirty] = useState(false);

  const ref = React.createRef<HTMLIonCardHeaderElement>();
  const formikRef = React.useRef<FormikProps<any>>(null);

  let stepIndexCount = 0;
  let reviewStepIndexCt = 0;



  useEffect(() => {
    ref.current?.scrollIntoView({
      behavior: 'smooth',
      block: 'center',
    });
  }, [activeStep])

  useEffect(() => {
    formikRef.current?.validateForm();
  }, [validationSchema]);

  useEffect(() => {
    config?.length > 0 && activeStep < config?.length && validatorSchema(config[activeStep].questions);
  }, [config]);

  const formBuilder = (ques: Question, formikProps: FormikProps<any>) => {
    if (checkDependsOnCond(ques, formikProps.values)) {
      return (
        <React.Fragment>
          {
            <>
              {
                builder(ques)
              }
              {
                ques.field && ques.field.map((q: Question, idx: any) => {
                  return <React.Fragment key={idx}> {
                    formBuilder(q, formikProps)
                  }
                  </React.Fragment>
                })
              }
            </>
          }
        </React.Fragment>
      )
    } else {
      formikProps.unregisterField(ques.id);
      formikProps.values[ques.id] = undefined;
    }
  }

  const builder = (c: Question) => {
    switch (c.type) {
      case 'text':
      case 'number':
        return (
          <Input name={c.id} label={c.name} type={c.type} hint={c.hint} dependsOn={c.valueDependsOn} helperData={helperData}
            identifier={c.identifier} placeholder={c.placeholder} isRequired={isRequired(c)} min={
              c.restrictions
                ? c.restrictions.find((x) => x.type === "min")?.value
                : 0
            }
            max={
              c.restrictions
                ? c.restrictions.find((x) => x.type === "max")?.value
                : ''
            } />
        );
      case 'number-inline':
        return (
          <Input name={c.id} label={c.name} type='number' hint={c.hint} dependsOn={c.valueDependsOn} helperData={helperData}
            identifier={c.identifier} placeholder={c.placeholder} inline='true' isRequired={isRequired(c)} min={
              c.restrictions
                ? c.restrictions.find((x) => x.type === "min")?.value
                : 0
            }
            max={
              c.restrictions
                ? c.restrictions.find((x) => x.type === "max")?.value
                : ''
            } />
        );
      case 'radio':
        return (
          <Radio name={c.id} options={c.options} hint={c.hint} label={c.name} isRequired={isRequired(c)} />
        )
      case 'multiselect':
        return (
          <MultiSelect options={c.options} name={c.id} hint={c.hint} label={c.name} isRequired={isRequired(c)} />
        );
      case 'inputselect':
        if (c.valueType && c.valueType === 'external') {
          c.options = helperData[c.identifier || ''];
        }
        return (
          <InputSelect name={c.id} label={c.name} isRequired={isRequired(c)} placeholder={c.hint} options={c.options} dependsOn={c.valueDependsOn} helperData={helperData} identifier={c.identifier}></InputSelect>
        );
      case 'select':
        if (c.valueType && c.valueType === 'external') {
          c.options = helperData[c.identifier || ''];
        }
        return (
          <Select options={c.options} name={c.id} label={c.name} dependsOn={c.valueDependsOn} helperData={helperData}
            identifier={c.identifier} placeholder={c.hint} isRequired={isRequired(c)} />
        )
      case 'slider':
        return (
          <NumberRange label={c.name} name={c.id} hint={c.hint} range={c.range} isRequired={isRequired(c)} />
        )
      case 'date':
        return (
          <DatePicker label={c.name} hint={c.hint} name={c.id} isRequired={isRequired(c)} />
        )
      default:
        return <Label label={c.name} hint={c.hint} name={c.id} isRequired={isRequired(c)} />
    }
  }

  const isRequired = (ques: Question) => {
    return ques.restrictions && ques.restrictions.some(restriction => {
      return restriction.type === 'required' && (!restriction.hasOwnProperty('dependsOn') || !!(formikRef.current?.values[restriction.dependsOn || '']));
    });
  }

  const answerDto = (ques: Question, answer: string) => {
    switch (ques.type) {
      case 'radio':
      case 'select':
        return ques.options?.find(opt => opt.id === answer)?.value;
      case 'multiselect':
        const answers = answer?.split(',');
        return ques.options?.filter(opt => answers?.includes(opt.id)).map(option => option.value).join(', ');
      case 'date':
        return answer ? format(parseISO(answer), 'MM-dd-yyyy') : '';
      default:
        return answer;
    }
  }

  const validatorSchema = (c: Question[]) => {
    let schema: any = {};
    c.forEach((question: Question) => {
      schema[question.id] = getFieldValidator(question);
      if (question.hasOwnProperty('field') && !!question.field) {
        question.field.forEach(q => {
          if (q.id === question.id)
            return;
          schema[q.id] = getFieldValidator(q);
        })
      }
    });
    setValidationSchema(Yup.object().shape(schema));
  }

  const getFieldValidator = (question: Question) => {
    
    let validator: any;
    switch (question.type) {
      case 'number':
      case 'slider':
      case 'number-inline':
        validator = Yup.number();
        break;
      case 'date':
        validator = Yup.date();
        break;
      default:
        validator = Yup.string();
    }
    if (question.hasOwnProperty('dependsOn') && !!question.dependsOn) {

      const quesDependsOn = question.dependsOn;
      if (Array.isArray(quesDependsOn)) {
        validator = validator['when'](quesDependsOn.map(x=> x.questionId), {
          is: (...val: any) => {
            return quesDependsOn.map(x=> x.questionId).every((quesId: string) => {
              const quesDependsOnValues = quesDependsOn.find((dependsOnQues: DependsOn)=> dependsOnQues.questionId === quesId)?.valueId;
              return quesDependsOnValues?.some((quesDependsOnVal: any) => val.includes(quesDependsOnVal));
            });
          },
          then: (fieldValidator: any) => getValidations(fieldValidator, question)
        })
         return validator;
      } else {
        validator = applyConditionalValidation(validator, quesDependsOn, question);
      }
    } else {
      validator = getValidations(validator, question);
    }
    return validator;
  }

  const applyConditionalValidation = (validator:any, dependsOnObj: DependsOn, question: Question) => {
    validator = validator['when'](dependsOnObj.questionId, {
      is: (val: any) => val?.split(',').some((value: string) => dependsOnObj.valueId.includes(value)),
      then: (fieldValidator: any) => getValidations(fieldValidator, question)
    })
    return validator;
  }

  const getValidations = (validator: any, question: Question) => {
    question.restrictions?.forEach((restriction: any) => {
      const { type, value, message, dependsOn, valueDependsOn } = restriction;
      let errMessage = message || ValidationMsg[type];
      let valType;
      switch (type) {
        case 'minlength':
          valType = 'min';
          break;
        case 'maxlength':
          valType = 'max';
          break;
        case 'mindate':
          valType = 'min';
          break;
        default:
          valType = type;
      }
      const params = value ? [value, errMessage] : (valueDependsOn ? [Yup.ref(valueDependsOn), errMessage] : [errMessage]);
      if (!validator[valType]) {
        return;
      }
      validator = dependsOn ? validator['when'](dependsOn, {
        is: (val: any) => !!val,
        then: validator[valType](...params)
      }) : validator[valType](...params);
    });
    return validator;
  }

  const checkDependsOnCond = (q: Question | QuestionnaireSection, formValues: any) => {
      return !q.hasOwnProperty('dependsOn') || evaluateDependsOn(q, formValues);
  }

  const evaluateDependsOn = (q: Question | QuestionnaireSection, formValues: any) => {
    if (Array.isArray(q['dependsOn'])) {
      return q['dependsOn'].every((dependsOnCond: DependsOn) => {
        return !dependsOnCond.hasOwnProperty('applicableRounds') ?
          formValues[dependsOnCond.questionId]?.split(',').some((val: string) => dependsOnCond['valueId'].includes(val)) :
          (dependsOnCond['applicableRounds']?.includes(round) && formValues[dependsOnCond.questionId]?.split(',').some((val: string) => dependsOnCond['valueId'].includes(val)));
      })
    }
    return !q['dependsOn'].hasOwnProperty('applicableRounds') ?
      formValues[q['dependsOn']['questionId']]?.split(',').some((val: string) => (q.dependsOn as DependsOn)['valueId'].includes(val)) :
      (!q['dependsOn']['applicableRounds']?.includes(round) ||
        formValues[q['dependsOn']['questionId']]?.split(',').some((val: string) => (q.dependsOn as DependsOn)['valueId'].includes(val)));
  }

  const handleError = (errors: any) => {
    var validateErrors = {} as any;
    for (const key in errors) {
      validateErrors[key] = true;
    }

    formikRef.current?.setTouched(validateErrors);
    const firstErrorKey = Object.keys(formikRef.current?.errors as any)[0];
    const errorElement = document.getElementsByName(firstErrorKey);
    if (errorElement && errorElement.length) {
      const parentElement = errorElement[0]?.closest(".ion-padding-top");
      if (parentElement) {
        parentElement.setAttribute('style', 'scroll-margin: 45px !important');
        parentElement.scrollIntoView({
          behavior: "auto", block: "nearest", inline: "start"
        });
      }
    }
  }

  const goToStep = (stepIndex: number, action = ActionType.Next) => {
    if(action === ActionType.Next) {
      const errors = formikRef.current?.errors as any;
      if (errors && Object.keys(errors).length && Object.getPrototypeOf(errors) === Object.prototype) {
        handleError(errors);
        return;
      }
    }

    if (action === ActionType.Review) {
      stepIndex = stepIndexCount;
      setActiveStep(stepIndex);
      setValidationSchema(Yup.object().shape({}));
      return;
    }

    let sectionIdx = stepIndex;
    setActiveStep(stepIndex);
    if (stepIndex < stepIndexCount) {
      while(sectionIdx < stepIndexCount && (!checkDependsOnCond(config[sectionIdx], formikRef.current?.values) || config[sectionIdx].questions.length === 0)) {
        action === ActionType.Next ? sectionIdx+=1 : sectionIdx-=1;
      }
      sectionIdx < config.length ? validatorSchema(config[sectionIdx].questions) : setValidationSchema(Yup.object().shape({}));
    } else {
      setHasReviewed(true);
      setValidationSchema(Yup.object().shape({}))
    }
  }

  const getReviewSectionForQuestions = (questions: Question[], formikProps: FormikProps<any>, parentQuesId?: string) => {
    return questions.map((question: Question, idx: number) => {
      return (
        checkDependsOnCond(question, formikProps.values) && (!parentQuesId || question.id !== parentQuesId) && <React.Fragment key={idx}>
          {question.name && <IonRow className='ion-padding-top'>
            <h3>{question.name}</h3>
          </IonRow>}
          <IonRow>
            <IonText className='review-answer-text'>{answerDto(question, formikProps.values[question.id])}</IonText>
          </IonRow>
          {
            question.field && getReviewSectionForQuestions(question.field, formikProps)
          }
        </React.Fragment>
      )
    })
  }

  return (
    <IonGrid className="ion-no-padding">
      <Formik
        innerRef={formikRef}
        validateOnChange={true}
        initialValues={ formData ? formData : {}}
        validationSchema={validationSchema}
        onSubmit={(data, { setSubmitting, resetForm }) => {
          setSubmitting(true);
          onSubmit(data).then(() => {
            resetForm();
            setActiveStep(0);
            stepIndexCount = 0;
            reviewStepIndexCt = 0;
          }).finally(() => setSubmitting(false));
        }}>
        {(formikProps: FormikProps<any>) => {
          stepIndexCount = 0
          if (formikProps.dirty !== isFormDirty) {
            onFormStateChange(formikProps.dirty);
          }
          return(
          <Form>
            {config?.map((c: QuestionnaireSection, index: number) => {
              let stepIndex = 0;
              if (checkDependsOnCond(c, formikProps.values) && c.questions?.length > 0) {
                stepIndex = stepIndexCount;
                stepIndexCount++;
                console.log('checkheader---dependson--->',c.name)
                return (
                  <React.Fragment key={index}>
                    <IonRow>
                      <IonCol className="ion-no-padding display-flex flex-column" size="auto" sizeSm="auto">
                        <div className={`step-index-container margin-x-auto
                            ${activeStep === stepIndex ? 'active' : activeStep > stepIndex ? 'done' : ''}`}>
                          {activeStep > stepIndex ? <IonIcon icon={checkmark} /> : <IonText>{stepIndex + 1}</IonText>}
                        </div>
                        <div className="step-index-line margin-x-auto"></div>
                      </IonCol>
                      <IonCol className="ion-no-padding">
                        <IonCard className="no-margin-top" disabled={formikProps.isSubmitting}>
                          <IonCardHeader ref={activeStep === stepIndex ? ref : undefined} onClick={() => { (activeStep > stepIndex) && goToStep(stepIndex, ActionType.Back) }}>
                            <IonCardTitle>{c.name}
                            </IonCardTitle>
                            {activeStep === stepIndex && !!c.hint && <IonCardSubtitle>({c.hint})</IonCardSubtitle>}
                          </IonCardHeader>
                          {activeStep === stepIndex &&
                            <IonCardContent>
                              {c.questions?.map((question: Question, idx: number) => {
                                return <React.Fragment key={idx}> {
                                  formBuilder(question, formikProps)
                                }
                                </React.Fragment>
                              })}

                              <div className='ion-padding-top'>
                             {hasReviewed && <IonButton expand="block" className="ion-margin-top" onClick={() => goToStep(0, ActionType.Review)}>Back to review</IonButton>}
                                <IonButton expand="block" className="ion-margin-top" onClick={() => goToStep(activeStep + 1, ActionType.Next)}>Next</IonButton>
                                <IonButton expand="block" className="ion-margin-top" fill="outline" disabled={activeStep === 0} onClick={() => goToStep(activeStep - 1, ActionType.Back)}>Back</IonButton>
                              </div>

                            </IonCardContent>
                          }
                        </IonCard>
                      </IonCol>
                    </IonRow>
                  </React.Fragment>
                )
              }
            })}
            {/* Review and submit section*/
              <IonRow>
                <IonCol className="ion-no-padding display-flex flex-column" size="auto" sizeSm="auto">
                  <div className={`step-index-container margin-x-auto
                    ${activeStep === stepIndexCount ? 'active' : ''}`}>
                    <IonText>{stepIndexCount + 1}</IonText>
                  </div>
                </IonCol>
                <IonCol className="ion-no-padding">
                  <IonCard className="no-margin-top" disabled={formikProps.isSubmitting}>
                    <IonCardHeader ref={activeStep === stepIndexCount ? ref : undefined}>
                      <IonCardTitle>Review and Submit</IonCardTitle>
                    </IonCardHeader>
                    {activeStep === stepIndexCount &&
                      <IonCardContent>
                        {config?.map((c: QuestionnaireSection, index: number) => {
                          if (index === 0) {
                            reviewStepIndexCt = 0;
                          }
                          let stepIndex = 0;
                          if (checkDependsOnCond(c, formikProps.values)) {
                            stepIndex = reviewStepIndexCt;
                            reviewStepIndexCt++;
                            return (
                              <IonGrid key={index} className='ion-padding-bottom ion-margin-bottom' style={{ 'borderBottom': '1px solid #E3E3E3' }}>
                                <IonRow className='ion-padding-bottom'>
                                  <IonCol><h2>{c.name}</h2></IonCol>
                                  <IonCol size='auto'><IonButton fill='clear' style={{ 'height': 'auto' }} onClick={() => goToStep(stepIndex,  ActionType.Back)}>Edit</IonButton></IonCol>
                                </IonRow>
                                {getReviewSectionForQuestions(c.questions, formikProps)}
                              </IonGrid>
                            )
                          }
                        })
                        }
                        <div className='ion-padding-top'>
                          <IonButton expand="block" type='submit' className="ion-margin-top" disabled={!config || !formikProps.isValid || formikProps.isSubmitting} onClick={() => { }}>Submit</IonButton>
                          <IonButton expand="block" className="ion-margin-top" disabled={formikProps.isSubmitting} fill="outline" onClick={() => goToStep(activeStep - 1, ActionType.Back
                            )}>Back</IonButton>
                        </div>
                      </IonCardContent>
                    }
                  </IonCard>
                </IonCol>
              </IonRow>
            }
            {/* <pre>{JSON.stringify(formikProps.values, null, 2)}</pre>
            <pre>{JSON.stringify(formikProps.errors, null, 2)}</pre> */}
          </Form>
          )
        }}
      </Formik>
    </IonGrid>
    );
};

enum ActionType {
  Next = 'next', Back = 'back', Review = 'review'
}

export default DynamicForm;
