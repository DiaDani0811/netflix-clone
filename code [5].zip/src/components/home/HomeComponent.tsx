import { useMsal, useAccount } from '@azure/msal-react';
import { IonContent, IonRouterOutlet, IonSplitPane } from '@ionic/react';
import { IonReactRouter } from '@ionic/react-router';
import React from 'react';
import { Redirect, Route } from 'react-router-dom';
import { TokenClaim } from '../../models/TokenClaim';
import About from '../../pages/About/About';
import Assessments from '../../pages/Assessments/Assessments';
import Initiative from '../../pages/Inititative/Initiative';
import Protocols from '../../pages/Protocols/Protocols';
import { SharedStoreContextProvider } from '../../shared/SharedStore';
import Menu from '../menu/Menu';
import Settings from '../../pages/Admin/Settings';
import UserManagement from '../../pages/Admin/User/UserManagement';
import FacilityManagement from '../../pages/Admin/Facility/FacilityManagement';
import { AdminSharedStoreContextProvider } from '../../pages/Admin/AdminSharedStore';
import SubmittedRecords from '../../pages/Admin/SubmittedRecords/SubmittedRecords';

const Home: React.FC = () => {

    const { accounts, inProgress } = useMsal();
    const account = useAccount(accounts[0] || {});

    let tokenClaim: TokenClaim = account?.idTokenClaims as TokenClaim;
    return (
        <IonReactRouter>
            {/* !!account &&  */}
            <IonSplitPane contentId="main">
                <Menu name={`${tokenClaim ? tokenClaim.given_name : ''} ${tokenClaim ? tokenClaim.family_name : ''}`} />
                <IonContent id="main">
                    <SharedStoreContextProvider>
                        <IonRouterOutlet>
                            <Route path='/about' exact={true} component={About} />
                            <Route path="/protocols" exact={true} component={Protocols} />
                            <Route path="/protocols/:protocolId/facility/:facilityId/assessments" exact={true} 
                            render={(props) => (
                                <Assessments key={props.match.params.protocolId} {...props} />
                            )} />
                            <Route path="/protocols/:protocolId/facility/:facilityId/assessments/:assessmentId" exact={true} render={(props) => (
                                <Initiative key={props.match.params.assessmentId} {...props} />
                            )} />
                            <Redirect exact from="/" to="/protocols" />
                            <Route render={() => <Redirect to="/protocols" />} />
                            
                            <AdminSharedStoreContextProvider>  
                            {//SE-CHANGES
                             tokenClaim?.roles.some(x => x === 'soa.CustomerAdmin' || x === 'soa.SuperAdmin' || x === 'soa.User') &&                            
                                <React.Fragment>
                                <Route path="/admin/settings" exact={true} component={Settings} />
                                <Route path="/admin/submittedrecords" exact={true} component={SubmittedRecords} />
                                <Route path="/admin/settings/userManagement" exact={true} component={UserManagement} />
                                <Route path="/admin/settings/userManagement/:id" exact={true} component={UserManagement} />
                                <Route path="/admin/settings/facilityManagement" exact={true} component={FacilityManagement} />
                                <Route path="/admin/settings/facilityManagement/:id" exact={true} component={FacilityManagement} />
                                {/*SE-CHANGES <Redirect exact from="/admin" to="/admin/settings" />*/}
                                </React.Fragment>
                                }
                            </AdminSharedStoreContextProvider>
                        </IonRouterOutlet>
                    </SharedStoreContextProvider>
                </IonContent>
            </IonSplitPane>
        </IonReactRouter>
    );
};

export default Home;
