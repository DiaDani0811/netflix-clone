import { IonRow, IonCol, useIonRouter } from "@ionic/react";
import React, { useContext, useEffect, useState } from "react";
import { ApiService } from "../../core/ApiService";
import { AssessmentHistory } from "../../models/AssessmentHistory";
import { AssessmentType } from "../../models/AssessmentType";
import { Question, Questionnaire } from "../../models/Questionnaire";
import { QuestionnaireDto, QuestionnaireDtoMapper } from "../../models/QuestionnaireDto";
import { StandardAssessment } from "../../models/StandardAssessment";
import { StandardAssessmentDto } from "../../models/StandardAssessmentDto";
import { SharedStoreContext } from "../../shared/SharedStore";
import DynamicForm from "../dynamic-form/DynamicForm";
import AssessmentSubmittedCard from "./AssessmentSubmittedCard";

const StandardAssessmentTemplate: React.FC<{ initiative: StandardAssessment, currAssessmentHist?: AssessmentHistory,resumeFormData:any, markRoundComplete: (assessmentId: any) => void }> = ({ initiative, currAssessmentHist,resumeFormData, markRoundComplete }) => {
    const [questionnaire, setQuestionnaire] = useState<Questionnaire>({ name: '', sections: [] });
    const [assesmentSubmitted, setAssesmentSubmitted] = useState<boolean>(false);
    const [assessmentId, setAssessmentId] = useState<string>();
    const [helperData, setHelperData] = useState<string>();
    const [formData, setFormData] = useState<any>();
    const { selectedFacility, user } = useContext(SharedStoreContext);
    const [isFormState, setFormState] = useState(false);

    const [roundNumber, setRoundNumber] = useState<number>();

    const router = useIonRouter();

    useEffect(() => {
    
        if (!!currAssessmentHist) {
            setRoundNumber(currAssessmentHist.roundComplete + 1);
            setAssessmentId(currAssessmentHist.id);
            getHelperData(initiative.protocolId, currAssessmentHist.id);
        } else {
            setRoundNumber(1);
            getHelperData(initiative.protocolId);
        }
    }, [currAssessmentHist]);
 
    useEffect(() => {
        if(!!resumeFormData){
      
            var data = JSON.parse(resumeFormData)
            setFormData(data)
            // console.log('resumeData--->',JSON.parse(resumeFormData))
        }
        
        if (!!initiative && !!roundNumber) {
            const questionnaire: Questionnaire = JSON.parse(initiative?.questionnaire);
            questionnaire.sections.forEach(section => {
                section.questions = section.questions.filter(question => !question.rounds || question.rounds.includes(roundNumber));
            })
            setQuestionnaire(questionnaire);
        }
    }, [initiative, roundNumber])

    const getHelperData = (protocolId: number, assessmentId?: string) => {
        ApiService.get(`/api/facility/${selectedFacility.id}/protocol/${protocolId}/units${assessmentId ? `?assessmentId=${assessmentId}` : ''}`).then((resp: any) => {
            setHelperData(resp);
        });
    }



    const answerDto = (ques: Question, answer: string) => {
        switch (ques.type) {
            case 'radio':
            case 'select':
                return ques.options?.find(opt => opt.id === answer)?.value;
            case 'multiselect':
                const answers = answer?.split(',');
                return ques.options?.filter(opt => answers?.includes(opt.id)).map(option => option.value).join(', ');
            default:
                return answer;
        }
    }

    const setNextRoomData = () => {
        setAssesmentSubmitted(false)
        if (assessmentId) {
            const data = localStorage.getItem(assessmentId);
            if (data) setFormData(JSON.parse(data))
        }
      
    }


    const handleSubmit = (data: any) => {
        if (!!data && !!initiative && !!questionnaire) {
            const allQuestions = questionnaire.sections.reduce<Question[]>(((prev, curr) => {
                let fieldQues = prev.reduce<Question[]>((field, question) => {
                    return [...field, ...question.field || []]
                }, []);
                return [...prev, ...fieldQues, ...curr.questions]
            }), []);
            const QuestionDto: QuestionnaireDto[] = QuestionnaireDtoMapper(data, questionnaire);
            const unitNumberQues = allQuestions.find(question => question.identifier === 'unitNumber');
            const unitNameQues = allQuestions.find(question => question.identifier === 'unitName');
            const unitTypeQues = allQuestions.find(question => question.identifier === 'unitType');
            const shouldPersistQues = allQuestions.find(question => question.identifier === 'persist');
            if (unitNumberQues && unitNameQues && unitTypeQues && data[unitNumberQues.id] && data[unitNameQues.id] && data[unitTypeQues.id]) {
                const AssessmentDto: StandardAssessmentDto = {
                    StandardAssessmentTemplateId: initiative.id,
                    UserEmail: user.email,
                    FacilityId: selectedFacility.id,
                    CurrentRoundNumber: roundNumber?.toString(),
                    UnitLevelAssessments: [{
                        AssessmentData: {
                            Data: JSON.stringify(QuestionDto)
                        },
                        UnitNumber: answerDto(unitNumberQues, data[unitNumberQues.id]) || '',
                        UnitName: answerDto(unitNameQues, data[unitNameQues.id]) || '',
                        UnitType: answerDto(unitTypeQues, data[unitTypeQues.id]) || '',
                        Persist: !shouldPersistQues || (answerDto(shouldPersistQues, data[shouldPersistQues.id]) || '').split(',').some((val) => ["yes", true, 1].includes(val.toLowerCase()))
                    }]
                }

                return submitRoom(AssessmentDto)
                    .then(response => {
                        if (roundNumber === 1 && response) {
                            let unitData = {} as any;
                            unitData[unitTypeQues.id] = data[unitTypeQues.id];
                            unitData[unitNameQues.id] = data[unitNameQues.id]
                            localStorage.setItem(response as string, JSON.stringify(unitData));
                        }
                    });
            }
            return Promise.reject('An error occurred');
        }
        return Promise.reject('An error occurred');
    }

    const submitRoom = (assessment: StandardAssessmentDto) => {
        if (!!assessmentId) {
            assessment = { ...assessment, Id: assessmentId };
            return new Promise((resolve, reject) => {
                ApiService.put(`/api/assessment/${AssessmentType.Standard}/${assessmentId}`, assessment).then((resp: any) => {
                    resolve(resp);
                    setTimeout(() => {
                        setAssesmentSubmitted(true);
                    }, 100)
                }, (err: any) => reject(err));
            });
        }
        // first entry
        return new Promise((resolve, reject) => {
            ApiService.post(`/api/assessment/${AssessmentType.Standard}`, assessment).then((resp: any) => {
                setAssessmentId(resp);
                resolve(resp);
                setTimeout(() => {
                    setAssesmentSubmitted(true);
                }, 100)
            }, (err: any) => reject(err));
        });
    }

    const handleFormStateChange = (formState: boolean) => {
        setFormState(formState)
        // console.log ("state of form from req.assmt", formState)
    }
    return <> {!!roundNumber && <React.Fragment>
        <IonRow><IonCol>
            <h1 className='mb-half'>{questionnaire?.name}</h1>
            <h5 className="std-assessment-sub-title">
                Round {roundNumber} Data Entry
            </h5>
        </IonCol></IonRow>
        <IonRow style={{ 'flexGrow': 1 }}>
            <IonCol className='ion-no-padding pb-half'>
                {!assesmentSubmitted ?
                    helperData && <DynamicForm round={roundNumber} config={questionnaire?.sections || []} helperData={helperData} formData={formData} onSubmit={handleSubmit} onFormStateChange={handleFormStateChange}></DynamicForm> :
                    <AssessmentSubmittedCard roundNumber={roundNumber} nextRoom={setNextRoomData}
                        markRoundComplete={() => markRoundComplete(assessmentId)}></AssessmentSubmittedCard>
                }
            </IonCol>
        </IonRow>
    </React.Fragment>
    }</>
}

export default StandardAssessmentTemplate;