import { IonCol, IonRow, useIonRouter } from "@ionic/react";
import React from "react";
import { useContext, useEffect, useState } from "react";
import { ApiService } from "../../core/ApiService";
import { AssessmentHistory } from "../../models/AssessmentHistory";
import { AssessmentType } from "../../models/AssessmentType";
import { StandardAssessment } from "../../models/StandardAssessment";
import { SharedStoreContext } from "../../shared/SharedStore";
import ActiveStandardAssessmentCard from "./ActiveStandardAssessmentCard";
import StandardAssessmentTemplate from "./StandardAssessmentTemplate";

const StandardAssessmentOverview: React.FC<{ initiative: StandardAssessment }> = ({ initiative }) => {
    const [assessment, setAssessment] = useState<AssessmentHistory>();
    const [fillAssessment, setFillAssessment] = useState<boolean>(false);
    const { selectedFacility, user, updateFacilityInfo } = useContext(SharedStoreContext);

    const router = useIonRouter();

    useEffect(() => {
        // console.log("assesmenthistoryid----->",assessment?.id)
        !!initiative && getFacilityStandardAssessmentHistory();
    }, [initiative]);

    const getFacilityStandardAssessmentHistory = () => {
        ApiService.get(`/api/assessment/standard/history/facility/${selectedFacility.id}`).then((resp: AssessmentHistory[]) => {
            if (resp && resp.length) {
                const currStandardAssessment = resp.find(x => x.standardAssessmentTemplateId === initiative.id && x.status === 'InProgress');
                if (currStandardAssessment) {
                    // show history since an assessment is in progress
                    setAssessment(currStandardAssessment);
                } else {
                    // start filing new assessment, no assessment in progress
                    setFillAssessment(true);
                }
            } else {
                setFillAssessment(true);
                // start filing new assessment, no assessment in progress
            }
        })
    }

    const submitAssessment = () => {
        ApiService.put(`/api/assessment/standard/${assessment?.id}/submit`, {}).then(resp => {
            updateFacilityInfo(selectedFacility.id);
            router.push('/protocols', 'root', 'replace');
        }, err => {
            // console.log('Standard assessment submission error:', err);
        })
    }

    const markRoundComplete = (assessmentId? : string) => {

        ApiService.put(`/api/assessment/${AssessmentType.Standard}/${assessment?.id || assessmentId}/round/complete`, {}).then(resp => {
           if(assessment?.id) localStorage.removeItem(assessment.id);
           setFillAssessment(false);
           getFacilityStandardAssessmentHistory();
        }, err => {
            // console.log('Round complete api error:', err);
        })
    }
    const[resumeFormData,setResumeFormData] = useState<any>()
    const resumeAction = ()=>{
        if(assessment){
            var data = localStorage.getItem(assessment.id)
            setResumeFormData(data)
            setFillAssessment(true)
        }
       
    }
    return <>
        {!!initiative &&
            (fillAssessment ? <StandardAssessmentTemplate initiative={initiative} currAssessmentHist={assessment} markRoundComplete = {markRoundComplete} resumeFormData={resumeFormData} /> :
                !!assessment && <React.Fragment>
                    <IonRow><IonCol>
                        <h1 className='mb-half ion-text-capitalize'>{initiative?.name} <span>Overview</span></h1>
                        <h5 className="std-assessment-sub-title">
                            Active Assessment
                        </h5>
                    </IonCol></IonRow>
                    <IonRow style={{ 'flexGrow': 1 }}>
                        <IonCol className='ion-no-padding pb-half'>
                            <ActiveStandardAssessmentCard initiative={initiative} currAssessmentHist={assessment}
                                fillAssessment={resumeAction} submitAssessment={submitAssessment} markRoundComplete = {markRoundComplete} />
                        </IonCol>
                    </IonRow>
                </React.Fragment>
            )
        }</>
}

export default StandardAssessmentOverview;