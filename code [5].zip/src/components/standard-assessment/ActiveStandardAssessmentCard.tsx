import { IonButton, IonCard, IonCardContent, IonCol, IonGrid, IonIcon, IonItemDivider, IonLabel, IonRow } from "@ionic/react";
import { checkmarkCircle, chevronForwardOutline, enterOutline, timeOutline } from "ionicons/icons";
import { AssessmentHistory } from "../../models/AssessmentHistory";
import { StandardAssessment } from "../../models/StandardAssessment";

import './ActiveStandardAssessmentCard.css';

const ActiveStandardAssessmentCard: React.FC<{ initiative: StandardAssessment, currAssessmentHist: AssessmentHistory, fillAssessment:() => void, submitAssessment:() => void, markRoundComplete:()=> void }> = ({ initiative, currAssessmentHist, fillAssessment, submitAssessment, markRoundComplete }) => {

    return (
        <IonCard className='ion-no-margin h-100 active-assessment-card'>
            <IonCardContent className='h-100'>
                <IonGrid className='flex-grid'>
                    <IonRow>
                        <IonCol className='ion-no-padding'>
                            <h5 className="std-assessment-sub-title">
                                {initiative?.name}
                            </h5>
                        </IonCol>
                    </IonRow>
                    <IonRow className="ion-padding-top">
                        <IonCol className='ion-no-padding display-flex ion-align-items-center'>
                            <IonIcon color='primary' icon={enterOutline} style={{ 'fontSize': '24px', 'paddingRight': '10px' }} />
                            <IonLabel color="primary">
                                Last Activity <strong>{new Date(currAssessmentHist.updated).toLocaleString()}</strong>
                            </IonLabel>
                        </IonCol>
                    </IonRow>
                    <IonRow>
                        {
                            [...Array(currAssessmentHist.roundComplete)].map((e, i) => {
                                return <IonCol size='12' key={i} className='display-flex ion-align-items-center'>
                                    <IonIcon size='large' style={{ 'color': '#13A914', 'paddingRight': '10px' }} icon={checkmarkCircle}></IonIcon>
                                    <IonLabel color="primary"><strong>Round {i + 1} Complete</strong></IonLabel>
                                </IonCol>
                            })
                        }
                        {
                            (currAssessmentHist.currentRoundNumber > currAssessmentHist.roundComplete) && <IonCol size="12" className="display-flex ion-align-items-center">
                                <IonIcon size='large' style={{ 'color': '#13A914', 'paddingRight': '10px' }} icon={timeOutline}></IonIcon>
                                <IonLabel color="primary"><strong>Round {currAssessmentHist.currentRoundNumber} In progress</strong></IonLabel>
                            </IonCol>
                        }
                    </IonRow>
                    <IonRow style={{ 'marginTop': 'auto' }}>
                        <IonItemDivider mode="md"></IonItemDivider>
                        <IonCol size='12' className="ion-text-right">
                            <IonButton size='large' fill="clear" onClick={fillAssessment} disabled={currAssessmentHist.roundComplete === initiative.maxRounds}> 
                                {currAssessmentHist.currentRoundNumber > currAssessmentHist.roundComplete ? 'Resume' : 'Next Round'}
                                <IonIcon icon={chevronForwardOutline}></IonIcon>
                            </IonButton>
                        </IonCol>
                       { (currAssessmentHist.currentRoundNumber > currAssessmentHist.roundComplete) &&  <IonCol size='12'>
                            <IonButton className="secondary" fill="outline" expand="block" size="large" onClick={markRoundComplete}>Round Complete</IonButton>
                        </IonCol>
                        }
                        <IonCol size='12' className='ion-no-padding ion-margin-bottom ion-text-center'>
                            <IonButton disabled={initiative.minRounds > currAssessmentHist.roundComplete} expand="block" size="large" onClick={submitAssessment}>Submit Assessment</IonButton>
                            {(initiative.minRounds > currAssessmentHist.roundComplete) && <small>*minimum of <strong>{initiative.minRounds}</strong> round(s) must be completed before submission.</small>}
                        </IonCol>
                    </IonRow>
                </IonGrid>
            </IonCardContent>
        </IonCard>
    )

}

export default ActiveStandardAssessmentCard;