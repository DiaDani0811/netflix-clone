import { IonButton, IonCard, IonCardContent, IonCol, IonGrid, IonIcon, IonRow, IonText } from "@ionic/react";
import { checkmarkCircleOutline } from "ionicons/icons";

import './AssessmentSubmittedCard.css';

const AssessmentSubmittedCard: React.FC<{ roundNumber: number, nextRoom: () => void, markRoundComplete: () => void }> =
    ({ roundNumber, nextRoom, markRoundComplete }) => {

        return (
            <IonCard className='ion-no-margin h-100'>
                <IonCardContent className='h-100'>
                    <IonGrid className='flex-grid'>
                        <IonRow>
                            <IonCol className='ion-no-padding ion-text-center'>
                                <IonIcon icon={checkmarkCircleOutline} className='completed-icon' />
                            </IonCol>
                        </IonRow>
                        <IonRow className="ion-margin-top ion-padding-top">
                            <IonCol className='ion-no-padding ion-text-center'>
                                <IonText className='completed-text'>Round {roundNumber} successfully saved</IonText>
                            </IonCol>
                        </IonRow>
                        <IonRow style={{ 'marginTop': 'auto' }}>
                            <IonCol size='12' className='ion-no-padding ion-margin-bottom ion-text-center'>
                                <IonButton expand="block" size="large" onClick={nextRoom}
                                    routerDirection="none">Next Room</IonButton>
                            </IonCol>
                            <IonCol size='12' className='ion-no-padding ion-text-center'>
                                <IonButton expand="block" size="large" onClick={markRoundComplete}
                                    routerDirection="none">Round Completed</IonButton>
                            </IonCol>
                        </IonRow>
                    </IonGrid>
                </IonCardContent>
            </IonCard>
        )
    }

export default AssessmentSubmittedCard;