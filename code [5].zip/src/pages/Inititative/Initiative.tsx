import { IonCol, IonContent, IonGrid, IonLabel, IonPage, IonRow, useIonRouter, useIonViewDidEnter, useIonViewDidLeave } from '@ionic/react';
import { useContext, useState } from 'react';
import { useLocation, useParams } from 'react-router';
import FacilityInfo from '../../components/facility-info/FacilityInfo';
import Header from '../../components/header/Header';
import RequiredAssessmentTemplate from '../../components/required-assessment/RequiredAssessmentTemplate';
import StandardAssessmentOverview from '../../components/standard-assessment/StandardAssessmentOverview';
import { AssessmentType } from '../../models/AssessmentType';
import { RequiredAssessment } from '../../models/RequiredAssessment';
import { StandardAssessment } from '../../models/StandardAssessment';
import { SharedStoreContext } from '../../shared/SharedStore';
import './Initiative.css';

const Initiative: React.FC = () => {

  const [initiative, setInitiative] = useState<RequiredAssessment | StandardAssessment| null>();
  const [type, setType] = useState<AssessmentType>();
  const [isFormstate, setFormState] = useState(false);
  const { selectedFacility, navigatedToProtocol } = useContext(SharedStoreContext);

  // const { protocolId, assessmentId } = useParams<{ protocolId: string; assessmentId: string; }>();
  const location = useLocation()
  const protocolId = location.pathname.split('/')[2]
  const assessmentId = location.pathname.split('/')[6]
  const router = useIonRouter();

  const handleFormStateChange = (formState: boolean) => {
    setFormState(formState);
  };

  const getInititative = () => {
    const selectedProtocol = selectedFacility.protocols.find(x => x.id === protocolId);
    const selectedAssessment = ((selectedProtocol?.requiredAssessmentTemplate?.id === assessmentId) ?
      selectedProtocol.requiredAssessmentTemplate : selectedProtocol?.standardAssessmentTemplates.find(x => x.id === assessmentId));
    ((selectedProtocol?.requiredAssessmentTemplate?.id === assessmentId) ? setType(AssessmentType.Required) : setType(AssessmentType.Standard));
    setInitiative(selectedAssessment);
  }

  useIonViewDidEnter(() => {
    if (navigatedToProtocol) {
      getInititative();
    } else {
      router.push('/protocols', 'root', 'replace');
    }
  }, []);

  useIonViewDidLeave(() => {
    setInitiative(null);
  }, []);
  
  return (
    <IonPage>
      <Header formState={isFormstate} />
      <IonContent fullscreen>
        {/* <FacilityInfo></FacilityInfo> */}
        <IonRow className="ion-padding " style={{opacity:'40%'}}>
         <img style={{verticalAlign: 'middle', borderBottom: '1px solid lightgray',width:'50px'}} src="assets/icon/facility_icon.png" />
          <IonLabel className="ion-padding" style={{borderBottom:'1px solid lightgray',paddingLeft:'0'}}>
            {selectedFacility.facilityName}
          </IonLabel>
        </IonRow>
        {/* <IonGrid className='flex-grid'> */}
        <IonGrid>
          {/* <IonRow>
            <FacilityInfo></FacilityInfo>
          </IonRow> */}
          <IonRow className='no-padding'>
            <IonCol className='no-padding' offsetSm='2' sizeSm='7'>
              <IonGrid className='no-padding'>
                {
                  (!!initiative) && <>{
                    (type === AssessmentType.Required) ? <RequiredAssessmentTemplate initiative={initiative as RequiredAssessment} formStateChange ={handleFormStateChange}></RequiredAssessmentTemplate> :
                      <StandardAssessmentOverview initiative={initiative as StandardAssessment}></StandardAssessmentOverview>
                  }</>
                }
              </IonGrid>
            </IonCol>
          </IonRow>
        </IonGrid>
      </IonContent>
    </IonPage>
  );
};

export default Initiative;
