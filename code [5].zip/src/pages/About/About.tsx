
import { IonCol, IonContent, IonGrid, IonPage, IonRow, IonText } from '@ionic/react';
import Header from '../../components/header/Header';
import './About.css';

const About: React.FC = () => {

  const appName = `${process.env.REACT_APP_APP_NAME}`

  return (
    <IonPage>
      <Header />
      <IonContent fullscreen>
        <IonGrid className='flex-grid'>
          <IonRow>
            <IonCol>
              <h1 className='mb-half'>{appName}</h1>
            </IonCol>
          </IonRow>
          <IonRow>
            <IonCol>
              <IonText>Version: V1.0.0-beta</IonText>
            </IonCol>
          </IonRow>
          <IonRow>
            <IonCol>
              <h4>Release notes:</h4>
              <ul>
                <li>Release note 1</li>
                <li>Release note 2</li>
                <li>Release note 3</li>
                <li>Release note 4</li>
              </ul>
            </IonCol>
          </IonRow>
        </IonGrid>
      </IonContent>
    </IonPage>
  );
};

export default About;
