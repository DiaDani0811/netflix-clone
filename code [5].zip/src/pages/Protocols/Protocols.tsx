import { IonCol, IonContent, IonGrid, IonPage, IonRow } from '@ionic/react';
import { useContext, useEffect, useState } from 'react';
import FacilityInfo from '../../components/facility-info/FacilityInfo';
import Header from '../../components/header/Header';
import Tile from '../../components/tile/Tile';
import { Protocol } from '../../models/Protocol';
import { SharedStoreContext } from '../../shared/SharedStore';
import './Protocols.css';

const Protocols: React.FC = () => {
  const [protocolsList, setProtocolsList] = useState<Array<Protocol>>([]);
  const { selectedFacility, setProtocolNavigation } = useContext(SharedStoreContext);

  const getProtocolsList = () => {
    setProtocolsList([...selectedFacility.protocols])
  }

  useEffect(() => {
    setProtocolNavigation(true);
    if (!!selectedFacility) {
      getProtocolsList();
    }
  }, [selectedFacility]);

  return (
    <IonPage>
      <Header />
      <IonContent fullscreen>
        <FacilityInfo></FacilityInfo>
        <IonGrid className='no-padding'>
          <IonRow className='no-padding'>
            <IonCol className='no-padding' offsetSm='2' sizeSm='7'>
              <IonGrid>
                <IonRow className='ion-hide-sm-down'><IonCol>
                  <h1 className='mb-half'>Available Initiatives</h1>
                </IonCol></IonRow>
                <IonRow>
                  {protocolsList.map((protocol, index) => {
                    return <IonCol key={index} size="6" sizeXl='3'>
                      <Tile title={protocol.name} imgurl={protocol.logo} navigationUri={`/protocols/${protocol.id}/facility/${selectedFacility.id}/assessments`} />
                    </IonCol>;
                  })}
                </IonRow>
              </IonGrid>
            </IonCol>
          </IonRow>
        </IonGrid>
      </IonContent>
    </IonPage>
  );
};

export default Protocols;
