import { InteractionStatus } from '@azure/msal-browser';
import { useMsal } from '@azure/msal-react';
import { IonPage, IonContent, IonGrid, IonRow, IonCol, IonCard, IonCardContent, IonButton } from '@ionic/react';
import { useEffect } from 'react';
import Header from '../../components/header/Header';
import './Login.css';

const Login: React.FC = () => {

  const { instance, accounts, inProgress } = useMsal();

  useEffect(() => {
    instance.handleRedirectPromise().catch(err => {
      alert('There is an issue with your account. Please try again later. If issue persists contact the administrator.');
    })
  }, []);

  return (
    <IonPage>
      <Header />
      <IonContent fullscreen className='login-content'>
        <IonGrid className='h-100'>
          <IonRow className='login-row h-100'>
            <IonCol sizeXs='12' sizeSm='10' offsetSm='1' sizeMd='8' offsetMd='2' sizeLg='6' offsetLg='3' sizeXl='4' offsetXl='4' className='ion-text-center'>
              <IonCard className='login-card'>
                <IonCardContent className='ion-no-padding'>
                  <img className='soa-icon' src='assets/icon/soa_icon.png' />
                  <div className='ion-padding-top'>
                    <IonButton className='ion-margin-top login-button' disabled={inProgress === InteractionStatus.Login} onClick={() => instance.loginRedirect()}>Login</IonButton>
                  </div>
                  <div className='ion-padding-top'>
                    <IonButton className='ion-margin-top' fill='clear' size='small'>Having issues signing in?</IonButton>
                  </div>
                </IonCardContent>
              </IonCard>
            </IonCol>
          </IonRow>
        </IonGrid>
      </IonContent>
    </IonPage>
  );
};

export default Login;
