import {
  IonButton,
  IonCard,
  IonCardContent,
  IonCol,
  IonContent,
  IonItem,
  IonLabel,
  IonRow,
  IonToast,
  IonToggle,
  useIonRouter,
} from "@ionic/react";
import { Field, Form, Formik, FormikProps } from "formik";
import React, { Fragment, useContext, useEffect, useState } from "react";
import { Input } from "../../../components/common-components/Input";
import Header from "../../../components/header/Header";
import { ApiService } from "../../../core/ApiService";
import * as Yup from "yup";
import { useMsal } from "@azure/msal-react";
import { TokenClaim } from "../../../models/TokenClaim";
import { AdminSharedStoreContext } from "../AdminSharedStore";
import { MultiSelectDropdown } from "../../../components/common-components/MultiSelectDropdown";
import { isEqual } from "lodash";
import { OperationStatus, OperationType } from "../../../models/AdminSettings";

const UserManagement: React.FC = (props: any) => {
  const router = useIonRouter();

  type facilityType = {
    id: string;
    facilityName: string;
  };

  const { match } = props;
  const {
    userData,
    facilities,
    setOperationType,
    getAllUsers,
    operationStatus,
    setOperationStatus,
  } = useContext(AdminSharedStoreContext);
  const { instance, accounts } = useMsal();
  let tokenClaim: TokenClaim = accounts[0]?.idTokenClaims as TokenClaim;
  const formikRef = React.useRef<FormikProps<any>>(null);
  const [editableUserData, setEditableUserData] = useState<any>();
  const [isEditable, setIsEditable] = useState(false);
  const [isActive, setIsActive] = useState(false);
  const [isFormDirty, setFormDirty] = useState(false);
  
  const FacilityList = facilities.map((facility: facilityType) => (
    {id: facility.id , value: facility.facilityName }))
    
  useEffect(() => {   
    if (match.params) {
      const data = userData.filter((user: any) => {
        return user.email === match.params.id;
      });
      if (data && data.length > 0) {
        ApiService.get(`/api/user/${match.params.id}`).then((resp: any) => {
          if (!!resp) {
            var selectedFacilites = resp.facilities.map(
              (facility: any) => facility.facilityName
            );
            data[0].facilities = selectedFacilites;
            setIsEditable(true);
            setEditableUserData(data[0]);
            formikRef.current?.validateForm();
          }
        });
      }
    }
  }, []);

  const formValidationSchema = Yup.object().shape({
    firstName: Yup.string().required("First Name is required"),
    lastName: Yup.string().required("Last Name is required"),
    email: Yup.string()
      .email("Invalid email address")
      .required("Email is required"),
    confirmEmail: Yup.string()
      .email("Invalid email address")
      .required("Confirm Email is required")
      .oneOf([Yup.ref("email"), null], "Confirm email must match"),
    facilities: Yup.array().min(1).required("Facility is required"),
    isActive: Yup.boolean().notRequired(),
  });

  const handleSubmit = (data: any) => {
    setOperationType(OperationType.User);
    if (!!data) {
      const facilities = data.facilities
        .map((facility: any) =>
          FacilityList.find((obj: any) => obj.value === facility)
        )
        .map((facility: any) => ({ id: facility.id }));

      let userData = {
        firstName: data.firstName,
        lastName: data.lastName,
        email: data.email,
        facilities: [],
        isActive: data.isActive,
        mailSent: !!data.mailSent,
      };

      return new Promise((resolve, reject) => {
        if (isEditable) {
          userData.facilities = facilities;
          ApiService.put(`/api/user/${data.email}`, userData).then(
            (resp: any) => {
              resolve(resp);
              setOperationStatus(OperationStatus.Success);
              getAllUsers();
              setTimeout(() => {
                router.push("/admin/settings", "root", "replace");
              }, 1000);
            },
            (err: any) => {
              reject(err);
              setOperationStatus(OperationStatus.Fail);
            }
          );
        } else {
          let userRole = tokenClaim?.roles.find(
            (x) => x === "soa.CustomerAdmin" || x === "soa.SuperAdmin"
          );
          if (userRole) {
            ApiService.post(`/api/user/role/CustomerUser`, userData).then(
              (resp: any) => {
                resolve(resp);
                userData.facilities = facilities;
                ApiService.put(`/api/user/${data.email}`, userData).then(
                  (resp: any) => {
                    resolve(resp);
                    setOperationStatus(OperationStatus.Success);
                    getAllUsers();
                    setTimeout(() => {
                      router.push("/admin/settings", "root", "replace");
                    }, 1000);
                  },
                  (err: any) => {
                    reject(err);
                    setOperationStatus(OperationStatus.Fail);
                  }
                );
                setTimeout(() => {}, 1000);
              },
              (err: any) => {
                reject(err);
                setOperationStatus(OperationStatus.Fail);
              }
            );
          }
        }
      });
    }
  };

  return (
    <Fragment>
      <Header formState={isFormDirty} />
      <IonRow className="no-padding">
        <IonCol size="9">
          <IonItem lines="none">
            <h1> {isEditable ? "Edit User" : "Create New User"}</h1>
          </IonItem>
        </IonCol>
        <IonToast
          position="top"
          duration={3000}
          isOpen={OperationStatus.Fail === operationStatus}
          message="User with same name already exists."
        ></IonToast>
      </IonRow>

      {!!editableUserData && (
        <Formik
          innerRef={formikRef}
          validateOnChange={true}
          validationSchema={formValidationSchema}
          initialValues={
            editableUserData
              ? {
                  firstName: editableUserData?.firstName,
                  lastName: editableUserData?.lastName,
                  email: editableUserData?.email,
                  confirmEmail: editableUserData?.email,
                  facilities: editableUserData?.facilities,
                  isActive: editableUserData?.isActive,
                  mailSent: editableUserData?.mailSent,
                }
              : {}
          }
          onSubmit={(data, { resetForm }) => {
            handleSubmit(data);
            resetForm();
          }}
        >
          {(formikProps: FormikProps<any>) => {
            if (formikProps.dirty !== isFormDirty) {
              setFormDirty(formikProps.dirty);
            }

            return (
              <Form>
                <IonContent fullscreen>
                  <IonRow>
                    <IonCol size="10">
                      <IonCard>
                        <IonCardContent>
                          <IonRow>
                            <IonCol className="ion-padding">
                              <Input
                                name="firstName"
                                label="First Name"
                                type="text"
                                value={editableUserData?.firstName}
                                placeholder="First Name"
                                isRequired={true}
                              />
                            </IonCol>
                            <IonCol className="ion-padding">
                              <Input
                                name="lastName"
                                label="Last Name"
                                type="text"
                                value={editableUserData?.lastName}
                                placeholder="Last Name"
                                isRequired={true}
                              />
                            </IonCol>
                          </IonRow>
                          <IonRow>
                            <IonCol className="ion-padding">
                              <Input
                                disabled={isEditable}
                                name="email"
                                label="Email"
                                type="text"
                                value={editableUserData?.email}
                                placeholder="User Email"
                                isRequired="true"
                              />
                            </IonCol>
                            <IonCol className="ion-padding">
                              <Input
                                disabled={isEditable}
                                name="confirmEmail"
                                label="Confirm Email"
                                type="text"
                                value={editableUserData?.email}
                                placeholder="User Email"
                                isRequired="true"
                              />
                            </IonCol>
                          </IonRow>
                          <IonRow>
                            <IonCol className="ion-padding">
                              <MultiSelectDropdown
                                options={FacilityList}
                                name="facilities"
                                label="Assign Facility"
                                isRequired="true"
                              />
                            </IonCol>
                          </IonRow>
                          <IonRow>
                            <IonCol className="ion-padding">
                              <Field
                                as={IonToggle}
                                name="isActive"
                                placeholder="Active/Inactive"
                                id="isActive"
                                type="checkbox"
                                onIonChange={(e: any) =>
                                  formikProps.setFieldValue(
                                    "isActive",
                                    e.detail.checked
                                  )
                                }
                              />
                              <div
                                style={{
                                  marginTop: "-40px",
                                  marginLeft: "80px",
                                }}
                              >
                                <IonLabel>{"Active"}</IonLabel>
                              </div>
                            </IonCol>
                            <IonCol className="ion-padding"></IonCol>
                          </IonRow>
                          <IonRow>
                            <IonCol offset="9" className="ion-no-padding">
                              <IonButton
                                disabled={
                                  formikProps.isValid &&
                                  isEqual(
                                    formikProps.initialValues,
                                    formikProps.values
                                  )
                                }
                                className="ion-margin-top"
                                type="submit"
                                onClick={() => {}}
                              >
                                {isEditable
                                  ? "Save Changes"
                                  : "Create New User"}
                              </IonButton>
                              <IonButton
                                className="ion-margin-top"
                                fill="outline"
                                routerLink="/admin/settings"
                                onClick={() => {
                                  setOperationStatus(OperationStatus.None);
                                }}
                              >
                                Cancel
                              </IonButton>
                            </IonCol>
                          </IonRow>
                        </IonCardContent>
                      </IonCard>
                    </IonCol>
                  </IonRow>
                </IonContent>
              </Form>
            );
          }}
        </Formik>
      )}

      {!editableUserData && (
        <Formik
          innerRef={formikRef}
          validateOnChange={true}
          validationSchema={formValidationSchema}
          initialValues={{}}
          onSubmit={(data) => {
            handleSubmit(data);
          }}
        >
          {(formikProps: FormikProps<any>) => {
            let value = 0;
            if (formikProps.dirty !== isFormDirty) {
              setFormDirty(formikProps.dirty);
            }
            return (
              <Form>
                <IonContent fullscreen>
                  <IonRow>
                    <IonCol size="10">
                      <IonCard>
                        <IonCardContent>
                          <IonRow>
                            <IonCol className="ion-padding">
                              <Input
                                disabled={isEditable}
                                name="firstName"
                                label="First Name"
                                type="text"
                                value={editableUserData?.firstName}
                                placeholder="First Name"
                                isRequired={true}
                              />
                            </IonCol>
                            <IonCol className="ion-padding">
                              <Input
                                disabled={isEditable}
                                name="lastName"
                                label="Last Name"
                                type="text"
                                value={editableUserData?.lastName}
                                placeholder="Last Name"
                                isRequired={true}
                              />
                            </IonCol>
                          </IonRow>
                          <IonRow>
                            <IonCol className="ion-padding">
                              <Input
                                disabled={isEditable}
                                name="email"
                                label="Email"
                                type="text"
                                value={editableUserData?.email}
                                placeholder="User Email"
                                isRequired="true"
                              />
                            </IonCol>
                            <IonCol className="ion-padding">
                              <Input
                                disabled={isEditable}
                                name="confirmEmail"
                                label="Confirm Email"
                                type="text"
                                value={editableUserData?.email}
                                placeholder="User Email"
                                isRequired="true"
                              />
                            </IonCol>
                          </IonRow>
                          <IonRow>
                            <IonCol className="ion-padding">
                              <MultiSelectDropdown
                                options={
                                  FacilityList.length > 0 ? FacilityList : {}
                                }
                                name="facilities"
                                value={editableUserData?.facilities}
                                label="Assign Facility"
                                isRequired="true"
                              />
                            </IonCol>
                          </IonRow>
                          <IonRow>
                            <IonCol className="ion-padding">
                              <Field
                                as={IonToggle}
                                name="isActive"
                                placeholder="Active/Inactive"
                                id="isActive"
                                type="checkbox"
                                onIonChange={(e: any) => {
                                  setIsActive(e.detail.checked);
                                  formikProps.setFieldValue(
                                    "isActive",
                                    e.detail.checked
                                  );
                                }}
                              />
                              <div
                                style={{
                                  marginTop: "-40px",
                                  marginLeft: "80px",
                                }}
                              >
                                <IonLabel>{"Active"}</IonLabel>
                              </div>
                            </IonCol>
                            <IonCol className="ion-padding"></IonCol>
                          </IonRow>
                          <IonRow>
                            <IonCol offset="9" className="ion-no-padding">
                              <IonButton
                                disabled={!formikProps.isValid}
                                className="ion-margin-top"
                                type="submit"
                                onClick={() => {}}
                              >
                                {isEditable
                                  ? "Save Changes"
                                  : "Create New User"}
                              </IonButton>
                              <IonButton
                                className="ion-margin-top"
                                fill="outline"
                                routerLink="/admin/settings"
                                onClick={() => {
                                  setOperationStatus(OperationStatus.None);
                                }}
                              >
                                Cancel
                              </IonButton>
                            </IonCol>
                          </IonRow>
                        </IonCardContent>
                      </IonCard>
                    </IonCol>
                  </IonRow>
                </IonContent>
              </Form>
            );
          }}
        </Formik>
      )}
    </Fragment>
  );
};
export default UserManagement;
