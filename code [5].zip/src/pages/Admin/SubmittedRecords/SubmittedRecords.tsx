import { IonContent, IonLabel, IonPage, IonCol, IonRow, IonGrid, IonItem, IonSelect, IonSelectOption, IonButton, IonSearchbar, IonCheckbox, IonInput, IonDatetime, IonDatetimeButton, IonModal, IonCard, IonCardHeader, IonCardContent, IonCardTitle, IonCardSubtitle, IonList } from "@ionic/react";
import React, { useContext, useEffect, useRef, useState } from "react";
import Header from "../../../components/header/Header";
import { AdminSharedStoreContext } from "../AdminSharedStore";
import "./SubmittedRecords.css";
import { ApiService } from "../../../core/ApiService";
import { User } from "../../../models/User";
import { Protocol } from "../../../models/Protocol";
import { StandardAssessment } from "../../../models/StandardAssessment";
import Pagination from "../../../components/common-components/Pagination";
import Details from "./TableData";
import { Facility } from "../../../models/Facility";
import { boolean } from "yup";



type userDataObject = {
  id: string;
  firstName: string;
  email : string
};

type tableData =
  {
    facility: string,
    assesmentType: string,
    unit: string,
    byHome: string,
    id: string,
    createDate: string,
  }

const SubmittedRecords: React.FC = () => {

  const paginatorRef = useRef<any>();

  const { userData } = useContext(AdminSharedStoreContext);
  const [facility, setFacility] = useState<Array<Facility>>([]);
  const [protocol, setProtocol] = useState<Array<Protocol>>([]);
  const [startDate, setStartDate] = useState<any>()
  const [endDate, setEndDate] = useState<any>()

  const [selectedUserId,setSelectedUserId] = useState<String>("All");
  const [selectedFacilityId,setSelectedFacilityId] = useState<String>("All");
  const [selectedProtocolId,setSelectedProtocolId] = useState<String>("All");

  /****Pagination****/
  const [dataSet, setDataSet] = useState<Array<tableData>>([]);
  const [tableData, setTableData] = useState<Array<tableData>>([])

  const modal = useRef<HTMLIonModalElement>(null);


  /*const [activeStep, setActiveStep] = useState(0);
  const ref = React.createRef<HTMLIonCardContentElement>();
  useEffect(() => {
    ref.current?.scrollIntoView({
      behavior: 'smooth',
      block: 'center',
    });
  }, [activeStep])*/
  
  useEffect(() => {
     Result();
 }, [selectedUserId]);

 
 useEffect(() => {
  if(selectedFacilityId!="")
       Result();
}, [selectedFacilityId]);

 
useEffect(() => {
  if(selectedProtocolId!="")
        Result();
}, [selectedProtocolId]);


  var changedFacility = false;
  
  const userChangeEvent = (e: Event) => {
    const selectedUser= (e.target as HTMLInputElement).value;

    setSelectedUserId(selectedUser);
    setSelectedFacilityId("");
    setSelectedProtocolId("");
    const getFacilityAPIURL=(selectedUser==='All') ? `/api/facility` : `/api/user/${selectedUser}`;
    if(selectedUser==="All")
    {
      ApiService.get(getFacilityAPIURL).then((resp:Facility[]) => {
          (resp)? setFacility(resp) : setFacility(new Array<Facility>());
      })
    }else{
      
      ApiService.get(getFacilityAPIURL).then((resp: User) => {
         (resp) ? setFacility(resp.facilities) : setFacility(new Array<Facility>());
      })
      
    }
   
  }
  
  const facilityChangeEvent = (e: Event) => {
    const selectedFacility= (e.target as HTMLInputElement).value;
    setSelectedFacilityId(selectedFacility);
    setSelectedProtocolId("");
    ApiService.get(`/api/facility/${selectedFacility}/protocols`).then((resp: Facility) => {
      (resp) ?  setProtocol(resp.protocols) : setProtocol(new Array<Protocol>());
      
    })
    
  };

  const protocolChangeEvent = (e: Event) => {
      setSelectedProtocolId((e.target as HTMLInputElement).value);
  };


  /**** Pagination change function ****/
  const loadDataSet = (sIndex: number, eIndex: number) => {
    //setActiveStep(activeStep);
    setTableData(dataSet.slice(sIndex, eIndex));
    
  };

  /** Date Picker **/
  const changeStartDate = (e: Event) => {
    setStartDate((e.target as HTMLInputElement).value)
  };
  const changeEndDate = (e: Event) => {
  
    setEndDate((e.target as HTMLInputElement).value)
  };  
  const dateValidation=()=>{
    Result();
    modal.current?.dismiss('confirm');
  }
  
  const Result =()=>{
   var getResultApi="/api/auditreport/all"
    if(selectedUserId && selectedFacilityId && selectedProtocolId && startDate && endDate){
      getResultApi = `/api/auditreport/all?email=${selectedUserId}&facilityId=${selectedFacilityId}&protocolId=${selectedProtocolId}&startDate=${new Date(startDate).toLocaleDateString()}&endDate=${new Date(endDate).toLocaleDateString()}`
    }
    else if(selectedUserId !== 'All' && selectedFacilityId !== 'All' && selectedProtocolId !== 'All'){
      getResultApi = `/api/auditreport/all?email=${selectedUserId}&facilityId=${selectedFacilityId}&protocolId=${selectedProtocolId}`
    }
    else if(selectedUserId !== 'All' && selectedFacilityId !== 'All' ){
      getResultApi = `/api/auditreport/all?email=${selectedUserId}&facilityId=${selectedFacilityId}`
    }
    else if(selectedUserId !== 'All'  ){
      getResultApi = `/api/auditreport/all?email=${selectedUserId}`
    }
    else if(startDate && endDate){
      getResultApi = `/api/auditreport/all?startDate=${new Date(startDate).toLocaleDateString()}&endDate=${new Date(endDate).toLocaleDateString()}`
    }else if(selectedUserId === 'All' && selectedFacilityId === 'All' && selectedProtocolId === 'All'){
      getResultApi = `/api/auditreport/all`
    }
    ApiService.get(getResultApi).then((resp:any)=>{
      var assesment:any = []
      var requiredAssesment:any = []
      var  standardAssesments:any = []
      resp.forEach((element:any)=>{
        if(element.requiredAssesment.length != 0) {
          element.requiredAssesment.forEach((additional:any)=>{
            additional['assessmentName'] = element.assessmentName
            additional['facilityName'] = element.facilityName
            additional['user'] =  element.user
            additional['createdDate'] = new Date(element.created).toLocaleDateString()
          })  
          requiredAssesment.push(element.requiredAssesment[0])
        }
        if(element.unitLevelAssessment.length != 0) {
              element.unitLevelAssessment.forEach((additional:any)=>{
               additional['assessmentName'] = element.assessmentName
               additional['facilityName'] = element.facilityName
               additional['user'] =  element.user
               additional['createdDate'] = new Date(element.created).toLocaleDateString()
          })
          standardAssesments.push(element.unitLevelAssessment[0])
        }
      })
      standardAssesments.forEach((unitLevel:any) => {
        requiredAssesment.push(unitLevel)
      });
      requiredAssesment.forEach((requiredAssesment:any) => {
          assesment.push(requiredAssesment)
      });
  
      console.log('assesment--->',assesment);
         setDataSet(assesment) 
   
      /****Pagination Initial Call ****/
      if (paginatorRef.current != null) {
        setTableData(assesment.slice(0, 5));
        paginatorRef.current.initPagenator(assesment);
      }
    })
  }
  

  // ------Pagination Ends------->
  return (
    <IonPage>
      <Header />
      <IonContent fullscreen>
        <IonGrid>
          <IonRow className="no-padding">
            <IonCol size="12">
              <IonItem lines="none">
                <h1 style={{ marginTop: "10px" }}>Audit Report</h1>
              </IonItem>
            </IonCol>
          </IonRow>
          <IonRow class="rowSpace">
            <IonCol size-xl="3" size-md="6" size-xs="12" >
              <IonItem className="selectedBox">
                <IonSelect interface="popover" placeholder="Select User" value={selectedUserId} onIonChange={userChangeEvent}>

                  <IonModal keepContentsMounted={true}>

                    <IonSelectOption key="All" value="All">All User</IonSelectOption>
                    {
                      userData.map((userItem: userDataObject) => {
                        return <IonSelectOption key={userItem.id} value={userItem.email}>{userItem.firstName}</IonSelectOption>
                      })
                    }
                  </IonModal>
                </IonSelect>

              </IonItem>

            </IonCol>
            <IonCol size-xl="3" size-md="6" size-xs="12">
              <IonItem className="selectedBox">
                <IonSelect interface="popover" placeholder="Select Facility" value={selectedFacilityId} onIonChange={facilityChangeEvent} >
                  <IonSelectOption key="All" value="All">All Facility</IonSelectOption>
                  {
                    facility.map((facility: Facility) => {
                      return <IonSelectOption key={facility.id} value={facility.id}>{facility.facilityName}</IonSelectOption>
                    })
                  }
                </IonSelect>
              </IonItem>
            </IonCol>
            <IonCol size-xl="3" size-md="6" size-xs="12">

              <IonItem className="selectedBox">
                <IonSelect interface="popover" placeholder="Select Assesment Type" value={selectedProtocolId} onIonChange={protocolChangeEvent}>
                  <IonSelectOption key="All" value="All">All Protocal</IonSelectOption>
                  {
                    protocol.map((protocol: Protocol) => {
                      return <IonSelectOption key={protocol.id} value={protocol.id}>{protocol.name}</IonSelectOption>
                    })
                  }
                </IonSelect>
              </IonItem>
            </IonCol>

            {/* <IonCol size-xl="3" size-md="6" size-xs="12">
              <IonItem >
                <IonSelect interface="popover" placeholder="Select Assesment" onIonChange={assesmentChangeEvent}>
                <IonSelectOption key="All" value="All">All Assessment</IonSelectOption>
                  {
                    standardAssesment.map((standardAssesment: StandardAssessment) => {
                      return <IonSelectOption key={standardAssesment.id} value={standardAssesment}>{standardAssesment.name}</IonSelectOption>
                    })
                  }
                </IonSelect>
              </IonItem>
            </IonCol> */}

            <IonCol size-xl="3" size-md="6" size-xs="12" >
              <IonItem className="selectedBox">
                <IonRow >
                  <IonDatetimeButton datetime="startdate" ></IonDatetimeButton>  -
                  <IonDatetimeButton className="endDateButton" datetime="enddate"></IonDatetimeButton>
                </IonRow>
              </IonItem>





              <IonModal ref={modal} keepContentsMounted={true}>
                <IonRow>
                  <IonCol col-6>
                   <IonLabel>Start Date</IonLabel>
                    <IonDatetime
                      id="startdate"
                      presentation="date"
                      onIonChange={changeStartDate}
                    >
                    </IonDatetime>
                  </IonCol>
                  <IonCol col-6>
                    <IonLabel>End Date</IonLabel>
                    <IonDatetime
                      id="enddate"
                      presentation="date"
                      min={startDate}
                      onIonChange={changeEndDate}
                     
                    />
                  </IonCol>
                </IonRow>
                <IonRow >
                  <IonCol className="ion-text-center">
                  <IonButton className="submitButton" onClick={dateValidation}>Submit</IonButton>
                  </IonCol>
              
                </IonRow>
              </IonModal>
            </IonCol>

          </IonRow>

          <IonRow class="rowSpace" >

            <IonGrid>
              <IonRow className="tableRow" >
              {
                  tableData.map((item: any) => (
                    <IonCol size-xl="4" size-md="6" size-xs="12">
                      <IonCard className="card">
                        <IonCardHeader>
                          <IonCardTitle className="headerTxt">{item.facilityName}</IonCardTitle>
                          <IonCardSubtitle className="subHeaderTxt">{item.assessmentName}</IonCardSubtitle>
                        </IonCardHeader>
                        <IonCardContent >
                          <IonRow>
                            <IonCol>
                              { !!item.unitName &&
                             <IonList className="contentTxt">{item.unitName}</IonList>
                              }
                               { !item.unitName &&
                             <IonList className="contentTxt">-</IonList>
                              }
                              <IonList className="contentTxt">{item.user.firstName} {item.user.lastName}</IonList>
                            </IonCol>
                            <IonCol >
                              <IonList></IonList>
                              <IonList className="contentTxt ion-text-right">{item.createdDate}</IonList>

                            </IonCol>
                          </IonRow>
                        </IonCardContent>
                      </IonCard>
                    </IonCol>


                  ))}

              </IonRow>
            </IonGrid>

            <Pagination changeDataSet={loadDataSet} refs={paginatorRef} />
          </IonRow>

        </IonGrid>
      </IonContent>
    </IonPage>
  )
}
export default SubmittedRecords;