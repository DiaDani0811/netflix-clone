
const Details = [
    {
      facility: "Brighton Center Specialty Care",
      assesmentType: "Fall - SPOT Assessment",
      unit: "Med Surg",
      byHome: "Kaniskar",
      id: "1",
      createDate: "10/13/2023",
    },
    
    {
      facility: "Napa Valley Saint Helena",
      assesmentType: "Falls Prevention",
      unit: "Med Surg",
      byHome: "Prabhu",
      id: "2",
      createDate: "10/13/2023",
    },
    {
      facility: "Borgess Medical Center",
      assesmentType: "Falls -Spot Assesment",
      unit: "Med Surg",
      byHome: "Santo",
      id: "3",
      createDate: "10/13/2023",
    },
    
    {
      facility: "Borgess Medical Center",
      assesmentType: "Hapi Prevention",
      unit: "Med Surg",
      byHome: "Prabhu",
      id: "4",
      createDate: "10/13/2023",
    },
    
    {
      facility: "Brighton Center Specialty Care",
      assesmentType: "Hapi - SPOT Assessment",
      unit: "Med Surg",
      byHome: "Kaniskar",
      id: "5",
      createDate: "10/13/2023",
    },
    
    {
      facility: "Napa Valley Saint Helena",
      assesmentType: "Hapi Prevention",
      unit: "Med Surg",
      byHome: "Prabhu",
      id: "6",
      createDate: "10/13/2023",
    },
    

    {
      facility: "Borgess Medical Center",
      assesmentType: "Hapi - SPOT Assessment",
      unit: "Med Surg",
      byHome: "Santo",
      id: "7",
      createDate: "10/13/2023",
    },
    
    {
      facility: "Brighton Center Specialty Care",
      assesmentType: "Falls Prevention",
      unit: "Med Surg",
      byHome: "Prabhu",
      id: "8",
      createDate: "10/13/2023",
    },
    {
      facility: "Napa Valley Saint Helena",
      assesmentType: "Falls Prevention",
      unit: "Med Surg",
      byHome: "Prabhu",
      id: "2",
      createDate: "10/13/2023",
    },
    {
      facility: "Brighton Center Specialty Care",
      assesmentType: "Falls -Spot Assesment",
      unit: "Med Surg",
      byHome: "Kaniskar",
      id: "3",
      createDate: "10/13/2023",
    },
    
    {
      facility: "Borgess Medical Center",
      assesmentType: "Hapi Prevention",
      unit: "Med Surg",
      byHome: "Prabhu",
      id: "4",
      createDate: "10/13/2023",
    },
    
    {
      facility: "Napa Valley Saint Helena",
      assesmentType: "Hapi - SPOT Assessment",
      unit: "Med Surg",
      byHome: "Kaniskar",
      id: "5",
      createDate: "10/13/2023",
    },
    
    {
      facility: "Brighton Center Specialty Care",
      assesmentType: "Hapi Prevention",
      unit: "Med Surg",
      byHome: "Prabhu",
      id: "6",
      createDate: "10/13/2023",
    },
    

    {
      facility: "Borgess Medical Center",
      assesmentType: "Hapi - SPOT Assessment",
      unit: "Med Surg",
      byHome: "Santo",
      id: "7",
      createDate: "10/13/2023",
    },
    
    {
      facility: "Napa Valley Saint Helena",
      assesmentType: "Falls Prevention",
      unit: "Med Surg",
      byHome: "Prabhu",
      id: "8",
      createDate: "10/13/2023",
    },
    {
      facility: "Napa Valley Saint Helena",
      assesmentType: "Falls Prevention",
      unit: "Med Surg",
      byHome: "Prabhu",
      id: "2",
      createDate: "10/13/2023",
    },
    {
      facility: "Brighton Center Specialty Care",
      assesmentType: "Falls -Spot Assesment",
      unit: "Med Surg",
      byHome: "Kaniskar",
      id: "3",
      createDate: "10/13/2023",
    },
    
    {
      facility: "Brighton Center Specialty Care",
      assesmentType: "Hapi Prevention",
      unit: "Med Surg",
      byHome: "Prabhu",
      id: "4",
      createDate: "10/13/2023",
    },
    
    {
      facility: "Napa Valley Saint Helena",
      assesmentType: "Hapi - SPOT Assessment",
      unit: "Med Surg",
      byHome: "Kaniskar",
      id: "5",
      createDate: "10/13/2023",
    },
    
    {
      facility: "Napa Valley Saint Helena",
      assesmentType: "Hapi Prevention",
      unit: "Med Surg",
      byHome: "Prabhu",
      id: "6",
      createDate: "10/13/2023",
    },
    

    {
      facility: "Borgess Medical Center",
      assesmentType: "Hapi - SPOT Assessment",
      unit: "Med Surg",
      byHome: "Santo",
      id: "7",
      createDate: "10/13/2023",
    },
    
    {
      facility: "Napa Valley Saint Helena",
      assesmentType: "Falls Prevention",
      unit: "Med Surg",
      byHome: "Prabhu",
      id: "8",
      createDate: "10/13/2023",
    },
    {
      facility: "Brighton Center Specialty Care",
      assesmentType: "Falls Prevention",
      unit: "Med Surg",
      byHome: "Prabhu",
      id: "2",
      createDate: "10/13/2023",
    },
    {
      facility: "Napa Valley Saint Helena",
      assesmentType: "Falls -Spot Assesment",
      unit: "Med Surg",
      byHome: "Kaniskar",
      id: "3",
      createDate: "10/13/2023",
    },
    
    {
      facility: "Napa Valley Saint Helena",
      assesmentType: "Hapi Prevention",
      unit: "Med Surg",
      byHome: "Prabhu",
      id: "4",
      createDate: "10/13/2023",
    },
    
    {
      facility: "Borgess Medical Center",
      assesmentType: "Hapi - SPOT Assessment",
      unit: "Med Surg",
      byHome: "Kaniskar",
      id: "5",
      createDate: "10/13/2023",
    },
    
    {
      facility: "Brighton Center Specialty Care",
      assesmentType: "Hapi Prevention",
      unit: "Med Surg",
      byHome: "Prabhu",
      id: "6",
      createDate: "10/13/2023",
    },
    

    {
      facility: "Napa Valley Saint Helena",
      assesmentType: "Hapi - SPOT Assessment",
      unit: "Med Surg",
      byHome: "Santo",
      id: "7",
      createDate: "10/13/2023",
    },
    
    {
      facility: "Brighton Center Specialty Care",
      assesmentType: "Falls Prevention",
      unit: "Med Surg",
      byHome: "Prabhu",
      id: "8",
      createDate: "10/13/2023",
    },{
      facility: "Napa Valley Saint Helena",
      assesmentType: "Falls Prevention",
      unit: "Med Surg",
      byHome: "Prabhu",
      id: "2",
      createDate: "10/13/2023",
    },
    {
      facility: "Borgess Medical Center",
      assesmentType: "Falls -Spot Assesment",
      unit: "Med Surg",
      byHome: "Kaniskar",
      id: "3",
      createDate: "10/13/2023",
    },
    
    {
      facility: "Napa Valley Saint Helena",
      assesmentType: "Hapi Prevention",
      unit: "Med Surg",
      byHome: "Prabhu",
      id: "4",
      createDate: "10/13/2023",
    },
    
    {
      facility: "Napa Valley Saint Helena",
      assesmentType: "Hapi - SPOT Assessment",
      unit: "Med Surg",
      byHome: "Kaniskar",
      id: "5",
      createDate: "10/13/2023",
    },
    
    {
      facility: "Brighton Center Specialty Care",
      assesmentType: "Hapi Prevention",
      unit: "Med Surg",
      byHome: "Prabhu",
      id: "6",
      createDate: "10/13/2023",
    },
    

    {
      facility: "Napa Valley Saint Helena",
      assesmentType: "Hapi - SPOT Assessment",
      unit: "Med Surg",
      byHome: "Kaniskar",
      id: "7",
      createDate: "10/13/2023",
    },
    
    {
      facility: "Napa Valley Saint Helena",
      assesmentType: "Falls Prevention",
      unit: "Med Surg",
      byHome: "Prabhu",
      id: "8",
      createDate: "10/13/2023",
    },
    
    
    
  ];
  
  export default Details;
