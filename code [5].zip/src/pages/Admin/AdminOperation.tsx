import {
  IonBadge,
  IonButton,
  IonCol,
  IonItem,
  IonLabel,
  IonRow,
  useIonRouter,
} from "@ionic/react";
import { useHistory } from "react-router-dom";
import { OperationType } from "../../models/AdminSettings";
import "./Settings.css";

const AdminOperation = (props: any) => {
  const history = useHistory();
  const { operationType, data } = props;
  const router = useIonRouter();
  
  const navigateToOperation = (event: any) => {
    if (operationType === OperationType.User) {
      
      router.push(
        `/admin/settings/userManagement/${data.email}`,
        "root",
        "replace"
      );
    } else {
      router.push(
        `/admin/settings/facilityManagement/${data.id}`,
        "root",
        "replace"
      );
    }
  };
  return (
    <IonItem lines="none" onClick={(event) => navigateToOperation(event)}>
      <IonRow style={{ flexGrow: 1 }}>
        <IonCol size="8">
          {operationType === OperationType.User ? (
            <IonLabel>
              <h2 style={{ fontWeight: "bold" }}>
                {data.lastName}, {data.firstName}
              </h2>
              <h4>{data.email}</h4>
            </IonLabel>
          ) : (
            <IonLabel>
              <h2 style={{ fontWeight: "bold" }}>
                {data.organizationName}, {data.facilityName}
              </h2>
              <h4>{data.accountNumber}</h4>
            </IonLabel>
          )}
        </IonCol>
        {operationType === OperationType.User && <IonCol size="2" className="ion-text-center">
          <IonBadge className="badge-active">
            {data.isActive ? "Active" : "Inactive"}
          </IonBadge>
        </IonCol>}

        <IonCol size="1">
          <IonButton
            size="small"
            onClick={(event) => navigateToOperation(event)}
          >
            Edit
          </IonButton>
        </IonCol>
      </IonRow>
    </IonItem>
  );
};

export default AdminOperation;
