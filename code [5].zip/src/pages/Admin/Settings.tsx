import {
  IonButton,
  IonCard,
  IonCol,
  IonContent,
  IonGrid,
  IonImg,
  IonItem,
  IonLabel,
  IonList,
  IonPage,
  IonRow,
  IonSearchbar,
  IonSegment,
  IonSegmentButton,
  IonCardContent,
  IonToast
} from "@ionic/react";
import React, { useContext, useState, useEffect } from "react";
import Header from "../../components/header/Header";
import "./Settings.css";
import { ActiveInactiveType, OperationStatus, OperationType } from "../../models/AdminSettings";
import AdminOperation from "./AdminOperation";
import ButtonGroup from "../../components/common-components/ButtonGroup";
import { AdminSharedStoreContext } from "./AdminSharedStore";
import debounce from "lodash/debounce";

const Settings: React.FC = () => {
  const { userData, facilities, operationType, setOperationType, operationStatus, setOperationStatus } = useContext(AdminSharedStoreContext);
  const [buttonGroupItems, setButtonGroupItems] = useState([
    { name: ActiveInactiveType.Active, selected: true },
    { name: ActiveInactiveType.Inactive, selected: true },
  ]);
  
  const [searchText, setSearchText] = useState("search name or email");
  const [filteredUsers, setFilteredUsers] = useState(userData);
  const [filteredFacilities, setFilteredFacilities] = useState(facilities);
  const [totalItems, setTotalItems] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchString, setSearchString] = useState<any>(null);
 
  useEffect(() => {
    if (operationType === OperationType.User) {  
      setTotalItems(userData.length); 
    } else{  
      setTotalItems(facilities.length);  
    }  
  }, []);

  const filterData = debounce((event: any, type: string) => {
    const data = type === OperationType.User ? userData : facilities;
    if (!event.detail.value) {
      setTotalItems(data.length);
      return type === OperationType.User
        ? setFilteredUsers(data) 
        : setFilteredFacilities(data);
    }
   
    const result = data.filter((obj: any) => {
      const objectString = JSON.stringify(obj).toLowerCase();      
      return objectString.includes(event.detail.value.toLowerCase());
      }, true);

    setTotalItems(result.length)

    type === OperationType.User
      ? setFilteredUsers(result)
      : setFilteredFacilities(result);
  }, 300);


  const handleActiveInactive = (buttonGroup: any, clickedButton: any) => {
    setButtonGroupItems(buttonGroup);
    const data = operationType === OperationType.User ? userData : facilities;

    if (
      buttonGroup.every((item: any) => {
        return item.selected;
      })
    ) {
      operationType === OperationType.User
        ? setFilteredUsers(data)
        : setFilteredFacilities(data);
    } else if (
      buttonGroup.every((item: any) => {
        return !item.selected;
      })
    ) {
      operationType === OperationType.User
        ? setFilteredUsers([])
        : setFilteredFacilities([]);
    } else {
      if (clickedButton.name === ActiveInactiveType.Active) {
        const result = data.filter((x: any) => {
          return clickedButton.selected === x.isActive;
        });
        operationType === OperationType.User
          ? setFilteredUsers(result)
          : setFilteredFacilities(result);
      } else {
        const result = data.filter((x: any) => {
          return clickedButton.selected === !x.isActive;
        });
        operationType === OperationType.User
          ? setFilteredUsers(result)
          : setFilteredFacilities(result);
      }
    }
  };

  const pageSize = 10;
  const totalPages = Math.ceil(totalItems / pageSize);

  const handlePagination = (direction: 'prev' | 'next') => {
    if (direction === 'prev' && currentPage > 1) {
      setCurrentPage((prevPage) => prevPage - 1);
    } else if (direction === 'next' && currentPage < totalPages) {
      setCurrentPage((prevPage) => prevPage + 1);
    }
  };

  const getItemsForPage = (data: any) => {
    const startIndex = (currentPage - 1) * pageSize;
    const endIndex = startIndex + pageSize;
    return data.slice(startIndex, endIndex);
  };

  return (
    <IonPage>
      <Header />      
      <IonContent fullscreen>
        <IonGrid>
          <IonRow className="no-padding">
            <IonCol size="8">
              <IonItem lines="none">
                <h1 style={{ marginTop: "10px" }}>Admin Settings</h1>
              </IonItem>
              <IonToast position="top" duration={3000} isOpen={OperationStatus.Success === operationStatus} message="Record saved successfully."></IonToast>
            </IonCol>
            <IonCol offset=".3">
              <IonItem lines="none">
                <IonButton
                  title="Add User"
                  fill="clear"
                  size="large"
                  routerLink="/admin/settings/userManagement"
                  routerDirection="root"
                >
                  Add User
                  <IonImg
                    style={{ marginRight: "6px" }}
                    slot="start"
                    src="assets/icon/adduser.png"
                  ></IonImg>
                </IonButton>
                <IonButton
                  title="Add Facility"
                  fill="clear"
                  size="large"
                  routerLink="/admin/settings/facilityManagement"
                  routerDirection="root"
                >
                  Add Facility
                  <IonImg
                    slot="start"
                    src="assets/icon/addfacility.png"
                  ></IonImg>
                </IonButton>
              </IonItem>
            </IonCol>
          </IonRow>
        </IonGrid>
        <IonRow>
          <IonCol size="4" style={{marginLeft:'9px' }}>
            <IonSegment color="primary" value={operationType}>
              <IonSegmentButton
                value="user"
                onClick={() => {
                  setOperationType(OperationType.User);
                  setSearchText("search name or email");
                  setCurrentPage(1);
                  setSearchString(null)
                  setFilteredUsers(userData)
                }}
              >
                <h4>
                  <IonLabel>User</IonLabel>
                </h4>
              </IonSegmentButton>
              <IonSegmentButton
                value="facility"
                placeholder={searchText}
                onClick={() => {
                  setOperationType(OperationType.Facility);
                  setSearchText("search facility name or address");
                  setCurrentPage(1);
                  setSearchString(null)
                  setFilteredFacilities(facilities)
                }}
              >
                <h4>
                  <IonLabel>Facility</IonLabel>
                </h4>
              </IonSegmentButton>
            </IonSegment>
          </IonCol>
        </IonRow>
        <IonRow style={{marginTop:'-26px' }}>
          <IonCol>
            <IonCard >

              <IonRow>
                <IonCol size="4">
                  <IonSearchbar
                    value={searchString}
                    placeholder={searchText}
                    onIonChange={(e) => {filterData(e, operationType);
                    setSearchString(e.detail.value || null )}}
                  ></IonSearchbar>
                </IonCol>
                {operationType === OperationType.User && <IonCol size="6" offset="1.5" className="ion-padding-top ion-text-right">
                    <ButtonGroup
                      buttons={buttonGroupItems}
                      afterButtonGroupClicked={handleActiveInactive}
                    />
                </IonCol>}
              </IonRow >
              <IonCardContent >
              <IonList >
                {OperationType.User === operationType
                  ? getItemsForPage(filteredUsers).map((user: any) => {
                      return (
                        <AdminOperation
                          data={user}
                          operationType={operationType}
                          key={user.id}
                        />
                      );
                    })
                  : getItemsForPage(filteredFacilities).map((facility: any) => {
                      return (
                        <AdminOperation
                          data={facility}
                          operationType={operationType}
                          key={facility.id}
                        />
                      );
                    })}
              </IonList>
              </IonCardContent>
              <IonRow className="pagination">
                <IonCol size="6" offset="1.5" className="ion-padding-top ion-text-right">
                  <IonButton onClick={() => handlePagination('prev')} disabled={currentPage === 1}>
                    Prev
                  </IonButton>
                  <span>{currentPage}</span>
                  <IonButton onClick={() => handlePagination('next')} disabled={currentPage === totalPages}>
                    Next
                  </IonButton>
                </IonCol>
                
              </IonRow>
            </IonCard>
          </IonCol>
        </IonRow>
      </IonContent>
    </IonPage>
  );
};
export default Settings;

export enum SelectionType {
  All = "all",
  None = "none",
  Active = "active",
  Inactive = "inactive",
}
