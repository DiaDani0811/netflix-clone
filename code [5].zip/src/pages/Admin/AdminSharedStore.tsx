import React, { useEffect, useState } from "react";
import { ApiService } from "../../core/ApiService";
import { Facility } from "../../models/Facility";
import axios from "axios";
import { OperationStatus, OperationType } from "../../models/AdminSettings";

const AdminShareStore = {
  setOperationType: (val: string) => {},
  setOperationStatus: (val: string) => {},
  operationType: OperationType.User as string,
  operationStatus: OperationStatus.None as string,
  userData: [] as any,
  getAllUsers: () => {},
  facilities: [] as any,
  getAllFacilities: () => {},
  protocols: [] as any,
};

type FacilityList = {
  id: string;
  accountNumber: string;
  facilityName: string;
  organizationName: string;
  isActive: boolean;
  protocols: any;
};

type Userlist = {
  id: string;
  isActive: boolean;
  mailSent: boolean;
  email: string;
  firstName: string;
  lastName: string;
  facilities: any;
};

type ProtocolList = {
  id: string;
  name: string;
  description: string;
};

const AdminSharedStoreContext = React.createContext<{
  setOperationType: (val: string) => void;
  setOperationStatus: (val: string) => void;
  operationType: string;
  operationStatus: string;
  userData: any;
  getAllUsers: () => void;
  facilities: any;
  getAllFacilities: () => void;
  protocols: any;
}>(AdminShareStore);

function AdminSharedStoreContextProvider(props: { children: React.ReactNode }) {
  const [userData, setUserData] = useState<any>();
  const [facilities, setAllFacilities] = useState<Array<any>>([]);
  const [protocols, setAllprotocols] = useState<Array<any>>([]);
  const [operationType, setOperationType] = useState<string>(
    OperationType.User
  );
  const [operationStatus, setOperationStatus] = useState<string>(
    OperationStatus.None
  );

  useEffect(() => {
    getFacilities();
    getProtocols();
    getUsers();
  }, []);

  const getFacilities = () => {
    ApiService.get("/api/facility").then((resp: FacilityList[]) => {
      if (!!resp) {
        setAllFacilities(
          resp.map(
            ({
              id,
              accountNumber,
              facilityName,
              organizationName,
              protocols,
            }) => ({
              id,
              accountNumber,
              facilityName,
              organizationName,
              protocols,
            })
          )
        );
      }
    });
  };

  const getProtocols = () => {
    ApiService.get("/api/protocols").then((resp: ProtocolList[]) => {
      if (!!resp) {
        setAllprotocols(
          resp.map(({ id, name, description }) => ({ id, name, description }))
        );
      }
    });
  };

  const getUsers = () => {
    ApiService.get("/api/user/allusers").then((resp: Userlist[]) => {
      if (!!resp) {
        setUserData(
          resp.map(
            ({
              id,
              firstName,
              lastName,
              email,
              isActive,
              mailSent,
              facilities,
            }) => ({
              id,
              firstName,
              lastName,
              email,
              isActive,
              mailSent,
              facilities,
            })
          )
        );
      }
    });
  };

  return (
    (userData && facilities && protocols && (
      <AdminSharedStoreContext.Provider
        value={{
          userData,
          getAllUsers: getUsers,
          facilities,
          getAllFacilities: getFacilities,
          protocols,
          setOperationType,
          operationType,
          setOperationStatus,
          operationStatus,
        }}
      >
        {props.children}
      </AdminSharedStoreContext.Provider>
    )) ||
    null
  );
}

let AdminSharedStoreContextConsumer = AdminSharedStoreContext.Consumer;

export {
  AdminSharedStoreContext,
  AdminSharedStoreContextProvider,
  AdminSharedStoreContextConsumer,
};
