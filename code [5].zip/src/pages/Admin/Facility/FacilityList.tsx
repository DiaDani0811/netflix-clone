import {
  IonButton,
  IonCard,
  IonCardContent,
  IonCol,
  IonContent,
  IonGrid,
  IonIcon,
  IonItem,
  IonLabel,
  IonPage,
  IonRow,
} from "@ionic/react";
import { medical } from "ionicons/icons";
import React from "react";
import Header from "../../../components/header/Header";
import Facility from "./Facility";

const FacilityList: React.FC = (props: any) => {
  const facilities = [{}];

  const deleteFacilityHandler = (id: number) => {
    props.getFacilityId(id);
  };

  return (
    <IonPage>
      <Header />
      <IonContent fullscreen>
        <IonGrid>
          <IonRow className="no-padding">
            <IonCol>
              <IonItem lines="none">
                <IonIcon size="large" slot="start" icon={medical} />
                <h1 style={{'marginTop': '10px'}}>Facilities </h1>
              </IonItem>
            </IonCol>
            <IonCol sizeSm="true">
              <IonItem lines="none">
                <IonButton className="float-right"
                  size="default"
                  routerLink="/admin/facilities/addFacility"
                  routerDirection="root"
                >
                  Add Facility
                </IonButton>
              </IonItem>
            </IonCol>
          </IonRow>
        </IonGrid>
        <IonCard>
          <IonCardContent>
            <IonGrid>
              <IonRow className="no-padding">
                <IonCol size="4" className="ion-no-padding">
                  <h1>Organization Name</h1>
                </IonCol>
                <IonCol size="3" className="ion-no-padding">
                  <h1>Facility Name</h1>
                </IonCol>
                <IonCol size="3" className="ion-no-padding">
                  <h1>Account Number</h1>
                </IonCol>
                <IonCol size="2" className="ion-no-padding">
                  <IonLabel></IonLabel>
                </IonCol>
              </IonRow>
              {facilities.map((facility: any) => {
                return (
                  <Facility
                    facility={facility}
                    clickHander={deleteFacilityHandler}
                    key={facility.id}
                  />
                );
              })}
            </IonGrid>
          </IonCardContent>
        </IonCard>
      </IonContent>
    </IonPage>
  );
};
export default FacilityList;
