import {
    IonCol,
    IonGrid,
    IonIcon,
    IonItem,
    IonLabel,
    IonRow,
  } from "@ionic/react";
  import { trashBin } from "ionicons/icons";
  
  const Facility = (props: any) => {
    const { id, organizationName, facilityName, accountNumber } = props.facility;
    return (
      <IonGrid>
        <IonRow className="no-padding">
          <IonCol className="no-padding">
            <IonGrid>
              <IonRow>
                <IonCol size="4" key="organizationName" className='ion-no-padding'>
                      <IonLabel>{organizationName}</IonLabel>
                </IonCol>
                <IonCol size="3"  key="facilityName" className='ion-no-padding'>
                  <IonLabel >{facilityName}</IonLabel>
                </IonCol>
                <IonCol size="3" key="accountNumber" className='ion-no-padding'>
                  <IonLabel>{accountNumber}</IonLabel>
                </IonCol>
                <IonCol key="id" size="2" className='ion-no-padding ion-text-center'>
                  <IonItem lines="none">
                    <IonIcon
                      slot="start"
                      size="large"
                      icon={trashBin}
                      onClick={() => props.clickHander(id)}
                    ></IonIcon>
                  </IonItem>
                </IonCol>
              </IonRow>
            </IonGrid>
          </IonCol>
        </IonRow>
      </IonGrid>
    );
  };
  
  export default Facility;
  