import {
  IonButton,
  IonCard,
  IonCardContent,
  IonCol,
  IonContent,
  IonItem,
  IonRow,
  IonToast,
  useIonRouter,
} from "@ionic/react";
import { Form, Formik, FormikProps } from "formik";
import React, { Fragment, useContext, useEffect, useState } from "react";
import { Input } from "../../../components/common-components/Input";
import Header from "../../../components/header/Header";
import * as Yup from "yup";
import { ApiService } from "../../../core/ApiService";
import { SharedStoreContext } from "../../../shared/SharedStore";
import { AdminSharedStoreContext } from "../AdminSharedStore";
import { Protocol } from "../../../models/Protocol";
import "./Facility.css";
import { MultiSelectDropdown } from "../../../components/common-components/MultiSelectDropdown";
import { OperationStatus, OperationType } from "../../../models/AdminSettings";

type protocolType = {
  id: string;
  name: string;
};

const FacilityManagement: React.FC = (props: any) => {
  const router = useIonRouter();
  const { selectedFacility, setProtocolNavigation } =
    useContext(SharedStoreContext);
  const { match } = props;
  const {
    facilities,
    protocols,
    setOperationType,
    getAllFacilities,
    operationStatus,
    setOperationStatus,
  } = useContext(AdminSharedStoreContext);
  const [editableFacilityData, setEditableFacilityData] = useState<any>();
  const [isEditable, setIsEditable] = useState(false);
  const [protocolsList, setProtocolsList] = useState<Array<Protocol>>(
    selectedFacility.protocols
  );
  const [formValue, setFormValue] = useState();

  const formikRef = React.useRef<FormikProps<any>>(null);

  const ProtocolsList = protocols.map((protocol: protocolType) => ({
    id: protocol.id,
    value: protocol.name,
  }));

  useEffect(() => {
    if (match.params) {
      const data = facilities.filter((x: any) => {
        return x.id === match.params.id;
      });

      if (data && data.length > 0) {
        ApiService.get(`/api/facility/${match.params.id}`).then((resp: any) => {
          if (!!resp) {
            var selectedProtocols = resp.protocols.map(
              (protocols: any) => protocols.name
            );
            data[0].protocols = selectedProtocols;
            setIsEditable(true);
            setEditableFacilityData(data[0]);
          }
        });
      }
    }
    formikRef.current?.validateForm();
  }, []);

  const handleSubmit = (data: any) => {
    setOperationType(OperationType.Facility);
    if (!!data) {
      const protocols = data.protocols
        .map((protocol: any) =>
          ProtocolsList.find((obj: any) => obj.value === protocol)
        )
        .map((protocol: any) => ({ id: protocol.id, name: protocol.value }));

      let facilityData = {
        id: data.id,
        organizationName: data.organizationName,
        facilityName: data.facilityName,
        accountNumber: data.accountNumber,
        units: null,
        protocols: [],
      };

      return new Promise((resolve, reject) => {
        if (isEditable) {
          facilityData.protocols = protocols;
          setProtocolsList(protocols);
          editableFacilityData.protocols = protocols;
          ApiService.put(
            `/api/facility/${facilityData.id}/protocols`,
            facilityData
          ).then(
            (resp: any) => {
              resolve(resp);
              setOperationStatus(OperationStatus.Success);
              getAllFacilities();
              setTimeout(() => {
                router.push("/admin/settings", "root", "replace");
              }, 500);
            },
            (err: any) => {
              setOperationStatus(OperationStatus.Fail);
              reject(err);
            }
          );
        } else {
          ApiService.post(`/api/facility`, facilityData).then(
            (resp: any) => {
              resolve(resp);
              facilityData.protocols = protocols;
              ApiService.put(
                `/api/facility/${resp}/protocols`,
                facilityData
              ).then((response: any) => {
                resolve(response);
                setOperationStatus(OperationStatus.Success);
                getAllFacilities();
                setTimeout(() => {
                  router.push("/admin/settings", "root", "replace");
                }, 500);
              });
              setTimeout(() => {}, 500);
            },
            (err: any) => {
              setOperationStatus(OperationStatus.Fail);
              reject(err);
            }
          );
        }
      });
    }
  };

  const formValidationSchema = Yup.object().shape({
    organizationName: Yup.string().required("Organization Name is required"),
    facilityName: Yup.string().required("Facility Name is required"),
    accountNumber: Yup.number().required("Account Number is required"),
    protocols: Yup.array().min(1).required("Atleast select a protocol"),
  });

  return (
    <Fragment>
      <Header />
      <IonRow className="no-padding">
        <IonCol size="9">
          <IonItem lines="none">
            <h1> {isEditable ? "Edit Facility" : "Add New Facility"}</h1>
          </IonItem>
        </IonCol>
        <IonToast
          position="top"
          duration={3000}
          isOpen={OperationStatus.Fail === operationStatus}
          message="Facility with same name already exists."
        ></IonToast>
      </IonRow>
      {!!editableFacilityData && (
        <Formik
          innerRef={formikRef}
          validateOnChange={true}
          validateOnBlur={true}
          validationSchema={formValidationSchema}
          initialValues={{
            id: editableFacilityData.id,
            organizationName: editableFacilityData.organizationName,
            facilityName: editableFacilityData.facilityName,
            accountNumber: editableFacilityData.accountNumber,
            protocols: editableFacilityData.protocols,
          }}
          onSubmit={(data, { resetForm }) => {
            handleSubmit(data);
            resetForm();
          }}
        >
          {(formikProps: FormikProps<any>) => (
            <Form>
              <IonContent fullscreen>
                <IonRow>
                  <IonCol size="10">
                    <IonCard>
                      <IonCardContent>
                        <IonRow>
                          <IonCol>
                            <Input
                              name="facilityName"
                              label="Facility Name"
                              type="text"
                              value={editableFacilityData?.facilityName}
                              placeholder="Name"
                              isRequired={true}
                            />
                          </IonCol>
                          <IonCol>
                            <Input
                              name="accountNumber"
                              label="Facility Account Number"
                              type="number"
                              value={editableFacilityData?.accountNumber}
                              placeholder="Account Number"
                              isRequired={true}
                            />
                          </IonCol>
                        </IonRow>
                        <IonRow>
                          <IonCol>
                            <Input
                              name="organizationName"
                              label="Organization Name"
                              type="text"
                              value={editableFacilityData?.organizationName}
                              placeholder="Organisation"
                              isRequired={true}
                            />
                          </IonCol>
                          <IonCol>
                            <MultiSelectDropdown
                              multiple
                              options={ProtocolsList}
                              value={editableFacilityData?.protocols}
                              name="protocols"
                              label="Assign Protocol"
                              placeholder="Protocol"
                            />
                          </IonCol>
                        </IonRow>
                        <IonRow>
                          <IonCol offset="8.8" className="ion-no-padding">
                            <div className="ion-padding-top">
                              <IonButton
                                disabled={!formikProps.isValid}
                                className="ion-margin-top"
                                type="submit"
                                onClick={() => {}}
                              >
                                {isEditable
                                  ? "Save Changes"
                                  : "Create New Facility"}
                              </IonButton>
                              <IonButton
                                className="ion-margin-top"
                                fill="outline"
                                routerLink="/admin/settings"
                                onClick={() => {
                                  setOperationStatus(OperationStatus.None);
                                }}
                              >
                                Cancel
                              </IonButton>
                            </div>
                          </IonCol>
                        </IonRow>
                      </IonCardContent>
                    </IonCard>
                  </IonCol>
                </IonRow>
              </IonContent>
            </Form>
          )}
        </Formik>
      )}

      {!editableFacilityData && (
        <Formik
          innerRef={formikRef}
          validateOnChange={true}
          validateOnBlur={true}
          validationSchema={formValidationSchema}
          initialValues={{}}
          onSubmit={(data) => {
            handleSubmit(data);
          }}
        >
          {(formikProps: FormikProps<any>) => (
            <Form>
              <IonContent fullscreen>
                <IonRow>
                  <IonCol size="10">
                    <IonCard>
                      <IonCardContent>
                        <IonRow>
                          <IonCol>
                            <Input
                              name="facilityName"
                              label="Facility Name"
                              type="text"
                              value={editableFacilityData?.facilityName}
                              placeholder="Name"
                              isRequired={true}
                            />
                          </IonCol>
                          <IonCol>
                            <Input
                              name="accountNumber"
                              label="Facility Account Number"
                              type="number"
                              value={editableFacilityData?.accountNumber}
                              placeholder="Account Number"
                              isRequired={true}
                            />
                          </IonCol>
                        </IonRow>
                        <IonRow>
                          <IonCol>
                            <Input
                              name="organizationName"
                              label="Organization Name"
                              type="text"
                              value={editableFacilityData?.organizationName}
                              placeholder="Organisation"
                              isRequired={true}
                            />
                          </IonCol>
                          <IonCol>
                            <MultiSelectDropdown
                              options={ProtocolsList}
                              name="protocols"
                              label="Assign Protocol"
                              placeholder="Protocol"
                            />
                          </IonCol>
                        </IonRow>
                        <IonRow>
                          <IonCol offset="8.8" className="ion-no-padding">
                            <div className="ion-padding-top">
                              <IonButton
                                disabled={!formikProps.isValid}
                                className="ion-margin-top"
                                type="submit"
                                onClick={() => {}}
                              >
                                {isEditable
                                  ? "Save Changes"
                                  : "Create New Facility"}
                              </IonButton>
                              <IonButton
                                className="ion-margin-top"
                                fill="outline"
                                routerLink="/admin/settings"
                                onClick={() => {
                                  setOperationStatus(OperationStatus.None);
                                }}
                              >
                                Cancel
                              </IonButton>
                            </div>
                          </IonCol>
                        </IonRow>
                      </IonCardContent>
                    </IonCard>
                  </IonCol>
                </IonRow>
              </IonContent>
            </Form>
          )}
        </Formik>
      )}
    </Fragment>
  );
};
export default FacilityManagement;
