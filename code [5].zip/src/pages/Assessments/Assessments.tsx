import { IonCol, IonContent, IonGrid, IonLabel, IonPage, IonRow, useIonRouter, useIonViewDidEnter, useIonViewDidLeave } from '@ionic/react';
import { useState, useContext,useEffect, useMemo, useCallback} from 'react';
import { useLocation, useParams } from 'react-router';
import FacilityInfo from '../../components/facility-info/FacilityInfo';
import Header from '../../components/header/Header';
import Tile from '../../components/tile/Tile';
import { RequiredAssessment } from '../../models/RequiredAssessment';
import { StandardAssessment } from '../../models/StandardAssessment';
import { SharedStoreContext } from '../../shared/SharedStore';
import './Assessments.css';

const Assessments: React.FC = () => {

  const [isFormDirty, setFormDirty] = useState(false);


  const [assessments, setAssessments] = useState<{ requiredAssessmentTemplate?: RequiredAssessment, standardAssessmentTemplates?: Array<StandardAssessment> }>({});
  const { selectedFacility, navigatedToProtocol } = useContext(SharedStoreContext);

  // const { protocolId } = useParams<{ protocolId: string; }>();
  const location = useLocation();
  const protocolId = location.pathname.split('/')[2]


  const router = useIonRouter();

  const getAssessmentsOnProtocolId = () => {
    const selectedProtocol = selectedFacility.protocols.find(x => x.id === protocolId);
    setAssessments({ requiredAssessmentTemplate: selectedProtocol?.requiredAssessmentTemplate, standardAssessmentTemplates: selectedProtocol?.standardAssessmentTemplates });
    
  }
  

  
  useIonViewDidEnter(() => {
    if (navigatedToProtocol) {
      getAssessmentsOnProtocolId();
    } else {
      router.push('/protocols', 'root', 'replace');
    }
  }, []);

  useIonViewDidLeave(() => {
    setAssessments({});
  }, []);

  return (
    <IonPage>
      <Header />
      <IonContent fullscreen>
        {/* <FacilityInfo></FacilityInfo> */}
        <IonRow className="ion-padding " style={{opacity:'40%'}}>
         <img style={{verticalAlign: 'middle', borderBottom: '1px solid lightgray',width:'50px'}} src="assets/icon/facility_icon.png" />
          <IonLabel className="ion-padding" style={{borderBottom:'1px solid lightgray',paddingLeft:'0'}}>
            {selectedFacility.facilityName}
          </IonLabel>
        </IonRow>
        <IonGrid className='no-padding'>
          <IonRow className='no-padding'>
            <IonCol className='no-padding' offsetSm='2' sizeSm='7'>
              <IonGrid>
                <IonRow className='ion-hide-sm-down'><IonCol>
                  <h1 className='mb-half'>Available Assessments</h1>
                </IonCol></IonRow>
                <IonRow>
                  {assessments?.requiredAssessmentTemplate && <IonCol size="6" sizeXl="3">
                    <Tile subtitle={assessments?.requiredAssessmentTemplate?.name} imgurl={assessments?.requiredAssessmentTemplate?.logo}
                      disabled={selectedFacility.activeTemplates.findIndex(x => x.assessmentTemplateId === assessments.requiredAssessmentTemplate?.id) === -1}
                      navigationUri={`/protocols/${protocolId}/facility/${selectedFacility.id}/assessments/${assessments?.requiredAssessmentTemplate?.id}`} />
                  </IonCol>}
                  {assessments?.standardAssessmentTemplates?.map((assessment, index) => {
                    return <IonCol key={index} size="6" sizeXl="3">
                      <Tile subtitle={assessment.name} imgurl={assessment.logo}
                        disabled={selectedFacility.activeTemplates.findIndex(x => x.assessmentTemplateId === assessment?.id) === -1}
                        navigationUri={`/protocols/${protocolId}/facility/${selectedFacility.id}/assessments/${assessment.id}`} />
                    </IonCol>;
                  })}
                </IonRow>
              </IonGrid>
            </IonCol>
          </IonRow>
        </IonGrid>
      </IonContent>
    </IonPage>
  );
};

export default Assessments;
