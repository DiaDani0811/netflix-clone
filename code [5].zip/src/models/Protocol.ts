import { RequiredAssessment } from "./RequiredAssessment";
import { StandardAssessment } from "./StandardAssessment";

export interface Protocol {
    id: string;
    name: string;
    description: string;
    category: string;
    logo?: string;
    created: string;
    updated?: string;
    requiredAssessmentTemplate: RequiredAssessment;
    standardAssessmentTemplates: Array<StandardAssessment>;
    facilities:Array<any>;
}