import { Question, Questionnaire } from "./Questionnaire";

export interface QuestionnaireDto {
    questionId: string;
    questionType: string;
    questionText?: string;
    additionalInfo?: Array<QuestionnaireDto>;
    answers?: Array<{id: string, value: string}>;
}

export function QuestionnaireDtoMapper(data: any, questionnaire: Questionnaire ): Array<QuestionnaireDto> {
    let questionnaireDto: Array<QuestionnaireDto> = [];
    questionnaire.sections.forEach((section) => {
        questionnaireDto = [...questionnaireDto, ...getQuestionnaireDtoArray(data, section.questions)];
    });
    return questionnaireDto;
}

function getQuestionnaireDtoArray(data: any, questions: Array<Question>, parentQuesId? :string): Array<QuestionnaireDto> {
    let questionnaireDto: Array<QuestionnaireDto> = [];
    questions.forEach((ques) => {
        if (!parentQuesId || parentQuesId!== ques.id) {
            let dtoQuestion = getQuestionnaireDto(data, ques);
            if (!!dtoQuestion) {
                questionnaireDto.push(dtoQuestion);
            }
        }
    });
    return questionnaireDto;
}

function getQuestionnaireDto(data: any, ques: Question): QuestionnaireDto | null {
    if (!!data[ques.id]) {
        let questionDto: QuestionnaireDto = {
            questionId: ques.id,
            questionText: ques?.name || '',
            questionType: ques?.type,
            answers: answerDto(data[ques.id], ques),
            additionalInfo: getQuestionnaireDtoArray(data, ques.field || [], ques.id)
        }
        return questionDto;
    }
    return null;
}

function answerDto(answer: string, question: Question) {
    switch (question?.type) {
        case 'radio':
        case 'select':
            var questionAns = question.options?.find(opt => opt.id === answer);
            if (!!questionAns) {
                return [{ id: questionAns.id, value: questionAns.value}];
            }
            throw new Error("Selected option does not exist");
        case 'multiselect':
            const answers = answer?.split(',');
            let questionAnsArr = question.options?.filter(opt => answers?.includes(opt.id)).map(opt => ({
                id: opt.id, value: opt.value
            }));
            if (!!questionAnsArr) {
                return questionAnsArr;
            }
            throw new Error("One of the selected option does not exist");
        default:
            return [{id: createUUID(), value: answer?.toString()}];
      }
}

function createUUID() {
    return ([1e7] as any +-1e3+-4e3+-8e3+-1e11).replace(/[018]/g, (c:any) =>
      (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
    )
  }