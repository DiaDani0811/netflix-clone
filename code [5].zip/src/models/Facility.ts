import { Protocol } from "./Protocol";

export interface Facility {
    id: string;
    accountNumber: string;
    activeTemplates: Array<any>;
    facilityName: string;
    organizationName: string;
    protocols: Array<Protocol>;
    requiredAssessments: Array<any>;
    standardAssessments: Array<any>;
    units: Array<any>;
    users: Array<any>;
}