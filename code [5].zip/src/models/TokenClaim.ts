export interface TokenClaim {
    email: string;
    family_name: string;
    given_name: string;
    roles: Array<string>;
}