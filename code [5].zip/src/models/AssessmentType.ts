export enum AssessmentType {
    Required = 'required', Standard = 'standard'
}