export interface AssessmentHistory {
    id: string,
    startTime: string,
    endTime: string,
    status: string,
    currentRoundNumber: number,
    roundComplete: number,
    standardAssessmentTemplateId: string,
    userEmail: string,
    facilityId: string,
    standardAssessmentTemplate: string,
    unitLevelAssessments: any[],
    user: string,
    facility: string,
    created: string,
    updated: string
}