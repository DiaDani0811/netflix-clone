export enum UserRoleType {
    StrykerUser = 'soa.StrykerUser',
    StrykerAdmin = 'soa.SuperAdmin',
    CustomerAdmin='soa.CustomerAdmin',
    CustomerUser ='soa.CustomerUser'
  }

  export enum OperationType {
    User ='user',
    Facility = 'facility'
  }
  export enum OperationStatus {
    Success ='success',
    Fail = 'fail',
    None = "none"
  }

  export enum ActiveInactiveType {
    Active ='Active',
    Inactive = 'Inactive'
  }