export interface RequiredAssessment {
    id: string;
    name: string;
    protocolId: number;
    questionnaire: any;
    requiredAssessments: Array<any>;
    logo?: string;
    created: string;
    updated: string;
}