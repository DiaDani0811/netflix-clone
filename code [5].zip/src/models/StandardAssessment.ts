export interface StandardAssessment {
    id: string;
    name: string;
    minRounds: number;
    maxRounds: number;
    timeOutPeriodInMinutes: number;
    timeBetweenRoundsInMinutes: number;
    protocolId: number;
    questionnaire: any;
    standardAssessments: Array<any>;
    logo?: string;
    created: string;
    updated: string;
}