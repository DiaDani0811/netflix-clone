export interface StandardAssessmentDto {
    Id?: string;
    StandardAssessmentTemplateId: string;
    UserEmail: string;
    FacilityId: string;
    UnitLevelAssessments: [{
        AssessmentData: {
            Data: string;
        }
        UnitNumber: string;
        UnitName: string;
        UnitType: string;
        Persist?: boolean;
    }];
    CurrentRoundNumber?: string;
}