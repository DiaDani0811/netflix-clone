import { Facility } from "./Facility";

export interface User {
    email: string;
    facilities: Array<Facility>;
    requiredAssessments: Array<any>;
    standardAssessments: Array<any>;
}