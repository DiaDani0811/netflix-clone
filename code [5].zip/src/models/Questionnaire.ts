export interface Questionnaire {
    name: string;
    hint?: string;
    sections: Array<QuestionnaireSection>;

}

export interface QuestionnaireSection {
    name: string;
    hint?: string;
    dependsOn: DependsOn | Array<DependsOn>;
    questions: Array<Question>;
}

export interface Question {
    id: string;
    type: string;
    name: string;
    hint?: string;
    rounds?: Array<number>;
    range?: Array<number>; //min max for slider type question
    placeholder?: string;
    identifier?: string;
    dependsOn: DependsOn | Array<DependsOn>;
    valueType?:'external';
    valueDependsOn?: string;
    options?: Array<{
        id: string;
        value: string;
    }>;
    field?: Array<Question>;
    restrictions: Array<{
        type: string;
        value?: string;
        message?: string;
        dependsOn?: string;
        valueDependsOn?: string;
    }>;
}

export interface DependsOn {
    questionId: string;
    valueId: Array<string>;
    round?: number;
    applicableRounds?: Array<number>;
}