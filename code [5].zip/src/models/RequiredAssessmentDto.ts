export interface RequiredAssessmentDto {
    RequiredAssessmentTemplateId: string;
    UserEmail: string;
    FacilityId: string;
    AssessmentData: {
        Data: string;
    }
}