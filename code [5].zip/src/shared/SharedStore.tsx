import { useAccount, useMsal } from "@azure/msal-react";
import React, { useEffect, useState } from "react";
import { ApiService } from "../core/ApiService";
import { Facility } from "../models/Facility";
import { User } from "../models/User";

const ShareStore = {
    user: {} as User,
    allFacilities: [],
    navigatedToProtocol: false,
    selectedFacility: {} as Facility,
    updateFacilityInfo: (facilityId: string) => {},
    setProtocolNavigation: (val: boolean) => {}
}

const SharedStoreContext = React.createContext<{user: User, allFacilities: Array<Facility>,
    navigatedToProtocol: boolean, selectedFacility: Facility, updateFacilityInfo: (id: string) => void,
    setProtocolNavigation: (val: boolean) => void}>(ShareStore);

function SharedStoreContextProvider(props: { children: React.ReactNode; }) {

    const [user, setUser] = useState<User>();
    const [navigatedToProtocol, setNavigatedToProtocol] = useState<boolean>(false);
    const [allFacilities, setAllFacilities] = useState<Array<Facility>>([]);
    const [selectedFacility, setSelectedFacility] = useState<Facility>();

    const { accounts, inProgress } = useMsal();
    const account = useAccount(accounts[0] || {});

    useEffect(() => {
        if (!!account) {
            // call user api
            ApiService.get(`/api/user`).then((resp: User) => {
                if (!!resp) {
                    setUser(resp);
                    setAllFacilities(resp.facilities || []);
                    if ((resp.facilities || []).length > 0) {
                        const selectedFacility = resp.facilities[0];
                        getFacilityInfo(selectedFacility?.id);
                    } else {
                        // No facility assigned
                    }
                } else {
                    // no user found
                }
            });
        }
    }, [account]);

    const getFacilityInfo = (facilityId: string) => {
        ApiService.get(`/api/facility/${facilityId}`).then((resp) => {
            setSelectedFacility(resp);
        });
    }

    return (
        user && selectedFacility && <SharedStoreContext.Provider value={{ user, allFacilities, navigatedToProtocol, selectedFacility, updateFacilityInfo: getFacilityInfo, setProtocolNavigation: setNavigatedToProtocol }}>{props.children}</SharedStoreContext.Provider> || null
    )
}

let SharedStoreContextConsumer = SharedStoreContext.Consumer;

export { SharedStoreContext, SharedStoreContextProvider, SharedStoreContextConsumer };